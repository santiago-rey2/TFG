"""Backend-independent scan types and flow.

Everything outside gocator.backends (CLI, output writers) only uses what is defined
here, so the Gocator Protocol backend can be swapped for a GoSdk (ctypes) or GoPxL
backend without touching the rest.
"""

import contextlib
import itertools
import logging
import math
import threading
import time
import xml.etree.ElementTree as ET
from collections import Counter
from collections.abc import Callable, Generator
from dataclasses import dataclass, field, fields, replace
from typing import Protocol

import numpy as np

log = logging.getLogger(__name__)

INVALID_RANGE = -32768  # int16 height value meaning "no data"


class ScannerError(Exception):
    pass


class ScanTimeout(ScannerError):
    """No data within the timeout. Nothing is lost: receiving can simply be tried again."""


@dataclass
class Grid:
    """A uniformly sampled 2D image. Row = y (travel direction), column = x."""

    data: np.ndarray  # (length, width): int16 heights or uint8 intensity
    x_resolution: float  # mm per column
    y_resolution: float  # mm per row
    x_offset: float  # mm
    y_offset: float  # mm
    z_resolution: float | None = None  # mm per height count (heights only)
    z_offset: float | None = None  # mm (heights only)


@dataclass
class Scan:
    heights: Grid
    intensity: Grid | None = None
    frame_index: int | None = None
    timestamp_us: float | None = None


@dataclass
class ProfileBatch:
    """Consecutive profiles from one message group (the sensor may send several per message)."""

    frame_indexes: np.ndarray  # (count,) frame index of each profile
    timestamps_us: np.ndarray  # (count,)
    # Uniform spacing: (count, width) int16 heights. Point cloud: (count, width, 2) int16 (x, z) pairs.
    ranges: np.ndarray
    x_resolution: float  # mm per count
    z_resolution: float
    x_offset: float  # mm
    z_offset: float
    intensity: np.ndarray | None = None  # (count, width) uint8

    @property
    def uniform(self) -> bool:
        return self.ranges.ndim == 2


# Values of the Settings choice fields, in the order the sensor numbers them (the classic
# configuration XML and the GoSdk enums agree).
CHOICES = {
    "scan_mode": ("video", "range", "profile", "surface"),
    "trigger_source": ("time", "encoder", "input", "software"),
    "surface_generation": ("continuous", "fixed", "variable", "rotational"),
    "surface_start": ("sequential", "input", "software"),
    "frame_rate_limit": ("camera", "surface generation"),  # FrameRate maxSource
    "x_spacing_type": ("max-res", "balanced", "max-speed", "custom"),
    "orientation": ("normal", "opposite", "reverse", "grid"),  # layout (normal = wide with a buddy)
}


def format_number(value: float) -> str:
    return str(int(value)) if float(value).is_integer() else format(value, ".10g")


def check_range(label: str, value: float, lo: float | None, hi: float | None) -> None:
    """Reject a value outside the limits the sensor reports (None = no limit)."""
    if (lo is not None and value < lo) or (hi is not None and value > hi):
        bounds = ", ".join("?" if b is None else format_number(b) for b in (lo, hi))
        raise ScannerError(f"{label}: {format_number(value)} is outside the sensor's range [{bounds}]")


def choice_index(field: str, name: str, allowed: list[int] | None = None) -> int:
    """The sensor's number for a CHOICES value, checked against the options it allows now."""
    names = CHOICES[field]
    if name not in names:
        raise ScannerError(f"{field}: unknown value {name!r} (known: {', '.join(names)})")
    index = names.index(name)
    if allowed is not None and index not in allowed:
        available = [n for i, n in enumerate(names) if i in allowed]
        raise ScannerError(f"{field}: {name!r} is not available on this sensor now (available: {', '.join(available)})")
    return index


def choice_name(field: str, index: int) -> str:
    names = CHOICES[field]
    return names[index] if 0 <= index < len(names) else str(index)


@dataclass
class Settings:
    """Sensor settings the tool can read and change. None = unknown / leave unchanged."""

    scan_mode: str | None = None  # "video", "profile", "surface"
    trigger_source: str | None = None  # "time", "encoder", "input", "software"
    frame_rate: float | None = None  # Hz (time triggering)
    max_frame_rate: bool | None = None  # run at the highest rate the other settings allow
    exposure: float | None = None  # us
    uniform_spacing: bool | None = None  # resample to the x spacing on the sensor (off: point cloud data)
    surface_generation: str | None = None  # "continuous", "fixed", "variable", "rotational"
    surface_length: float | None = None  # mm, fixed-length surfaces
    surface_start: str | None = None  # "sequential", "input", "software" (fixed length only)
    travel_speed: float | None = None  # mm/s, used to scale y with time triggering
    active_area: tuple[float, float, float, float] | str | None = None  # (x, z, width, height) mm, or "max"
    # mm between columns of uniform data. Read: the spacing in use (also with a preset type);
    # written: a custom spacing (sets the type to custom unless x_spacing_type is a preset).
    x_spacing: float | None = None
    x_spacing_type: str | None = None  # "max-res", "balanced", "max-speed" (presets), "custom"
    # Camera subsampling: use every Nth camera column (x) or row (z). Read: the divisor in use;
    # written: that divisor (the sensor's default off, unless *_default is True).
    x_subsampling: int | None = None
    x_subsampling_default: bool | None = None  # the sensor picks (None: this sensor has no default)
    z_subsampling: int | None = None
    z_subsampling_default: bool | None = None
    # Read-only, computed by the sensor from the settings above (never applied).
    frame_rate_max: float | None = None  # Hz, the highest frame rate allowed now
    frame_rate_limit: str | None = None  # what sets frame_rate_max: "camera" or "surface generation"
    # Layout orientation. "reverse" mirrors x: the opposite handedness from "normal", which makes
    # images (rows going down) read correctly but 3D views of the same data mirrored.
    orientation: str | None = None

    def max_frame_rate_to_apply(self) -> bool | None:
        """An explicit frame rate only takes effect with max frame rate off."""
        if self.frame_rate is not None and self.max_frame_rate is None:
            return False
        return self.max_frame_rate

    def explicit_subsampling(self, axis: str) -> int | None:
        """The x or z subsampling to write: none when the sensor's default is being turned on."""
        return None if getattr(self, f"{axis}_subsampling_default") else getattr(self, f"{axis}_subsampling")

    def custom_x_spacing(self) -> float | None:
        """The custom x spacing to write: none when a preset type is being set."""
        return self.x_spacing if self.x_spacing_type in (None, "custom") else None

    def split_frame_rate(self) -> "tuple[Settings, Settings] | None":
        """(everything else, the frame rate) when both are set, else None.

        The sensor computes the frame rate's limits from the other settings (scan mode,
        surface length, exposure...), so a rate is checked after those are written.
        """
        rate = Settings(frame_rate=self.frame_rate, max_frame_rate=self.max_frame_rate)
        rest = replace(self, frame_rate=None, max_frame_rate=None)
        if rate == Settings() or rest == Settings():
            return None
        return rest, rate

    def needs_software_trigger(self) -> bool:
        return self.surface_generation == "fixed" and self.surface_start == "software"

    def differences(self, actual: "Settings") -> list[str]:
        """Requested (non-None) fields whose value in `actual` is different."""
        diffs = []
        for f in fields(self):
            want, got = getattr(self, f.name), getattr(actual, f.name)
            if want is None or want == "max":
                continue
            if not same_value(want, got):
                diffs.append(f"{f.name}: requested {want}, sensor has {got}")
        return diffs


READ_ONLY = {"frame_rate_max", "frame_rate_limit", "orientation"}  # computed by the sensor, or not handled


def same_value(a, b) -> bool:
    if isinstance(a, tuple) and isinstance(b, tuple):
        return len(a) == len(b) and all(abs(x - y) < 1e-6 for x, y in zip(a, b))
    if isinstance(a, float | int) and isinstance(b, float | int) and not isinstance(a, bool) and not isinstance(b, bool):
        return abs(a - b) < 1e-6
    return a == b


class Scanner(Protocol):
    """What every backend implements (see gocator.backends)."""

    def connect(self) -> None: ...
    def close(self) -> None: ...
    def enable_outputs(self) -> None: ...  # also done by start(); separate so it can come first
    def start(self) -> None: ...
    def stop(self) -> None: ...
    def trigger(self) -> None: ...
    def grab(self, timeout: float) -> Scan: ...
    def grab_profiles(self, timeout: float) -> ProfileBatch: ...  # the next group of profiles
    # Latest health indicator values by id (instances summed); with wait, first wait up to
    # that long for a new message. {} if the sensor sent none.
    def health(self, wait: float = 0.0) -> dict[int, int]: ...
    def sensor_info(self) -> dict[str, str | int]: ...  # serial, model, firmware
    def get_settings(self) -> Settings: ...
    def apply_settings(self, settings: Settings) -> None: ...
    def list_jobs(self) -> list[str]: ...
    def loaded_job(self) -> tuple[str, bool]: ...  # (name, has unsaved changes)
    def load_job(self, name: str) -> None: ...
    def save_job(self, name: str) -> None: ...
    def set_default_job(self, name: str) -> None: ...
    def ensure_stopped(self) -> None: ...
    def is_running(self) -> bool: ...  # the sensor's state (Get States): Running, not Ready
    # Sensor files, e.g. "_live.cfg" or "myjob.job" (classic firmware names).
    def list_files(self, extension: str = "") -> list[str]: ...
    def read_file(self, name: str) -> bytes: ...
    def write_file(self, name: str, data: bytes) -> None: ...


# Health indicators that count lost data (user manual, "Health Results"; GoSdk GoHealth.h).
# They are totals the sensor keeps; a scan's drops are how much they grew.
DROP_INDICATORS = {
    21000: "processing drops",  # CPU overload, buffer overflows
    21010: "trigger drops",  # triggers faster than the sensor can take (camera trigger drops included)
    21005: "Ethernet drops",
    21011: "output drops",
}
HEALTH_CPU, HEALTH_SPEED = 2007, 20001  # CPU usage (%), current frame rate (Hz)
HEALTH_LATENCY, HEALTH_MAX_LATENCY = 21001, 21002  # us: the latest profile's processing latency, the max since Start
HEALTH_SCAN_COUNT = 20005  # profiles (Profile mode) sent since Start
HEALTH_LINK = 2034  # network link status, bits below
LINK_SPEEDS = {0x01: "10 Mb/s half duplex", 0x02: "10 Mb/s full duplex", 0x04: "100 Mb/s half duplex",
               0x08: "100 Mb/s full duplex", 0x10: "1000 Mb/s half duplex", 0x20: "1000 Mb/s full duplex"}
# Names for other indicators the -v summary may show. The sensor can also send undocumented
# ones (shown by id), e.g. a breakdown of the processing drops.
INDICATOR_NAMES = {
    **DROP_INDICATORS,
    2007: "CPU usage (%)",
    2034: "network link status",
    2201: "camera trigger drops",
    20001: "speed (Hz)",
    20003: "spot count",
    20005: "scan count",
    20009: "internal temperature (m°C)",
    21001: "last processing latency (us)",
    21002: "max processing latency (us)",
    21003: "Ethernet output (bytes)",
    21004: "Ethernet rate (bytes/s)",
    21014: "analog output drops",
    21015: "digital output drops",
    21016: "serial output drops",
    21017: "controlled trigger drops",
    21018: "surface processing time (us)",
    21019: "max frame rate (Hz)",
}
HEALTH_WAIT = 2.5  # s to wait after Stop for a health message that includes the end of the scan


@dataclass
class ScanReport:
    """What the sensor reported about a scan (filled in by scan_pieces), for the scan's record."""

    health_received: bool = False
    drops: dict[str, int] = field(default_factory=dict)  # indicator name: count during the scan
    max_cpu: int | None = None  # %
    max_latency: float | None = None  # s
    latency_at_stop: float | None = None  # s: processing latency when the scan was stopped (profile scans)
    scan_count: int | None = None  # profiles the sensor sent (profile scans that were stopped)
    link: str | None = None
    log: list[str] = field(default_factory=list)  # sensor log entries added during the scan


class DropWatch:
    """Reports how much the sensor's drop counters grow during a scan."""

    def __init__(self, scanner: Scanner, report: ScanReport | None = None):
        self.scanner = scanner
        self.report = report or ScanReport()
        # Right after connecting there may be no health message yet: wait for the baseline.
        self.last = self._read() or self._read(wait=HEALTH_WAIT)
        self.first = dict(self.last)  # for the -v summary of everything that changed
        self.total = dict.fromkeys(DROP_INDICATORS, 0)
        self.received = bool(self.last)
        self.max_cpu: int | None = None
        self.report.link = check_link(self.last)

    def _read(self, wait: float = 0.0) -> dict[int, int]:
        try:
            return self.scanner.health(wait)
        except (ScannerError, OSError) as e:
            log.debug("could not read the health indicators: %s", e)
            return {}

    def update(self, when: str, wait: float = 0.0) -> None:
        """Add what the counters grew since the last update; warn about any growth."""
        now = self._read(wait)
        if not now:
            return
        self.received = True
        self.first = self.first or dict(now)
        grown = []
        for indicator, name in DROP_INDICATORS.items():
            if indicator not in now:
                continue
            before = self.last.get(indicator, 0)
            # A counter below its last value was reset (e.g. on Start): it counts from 0.
            delta = now[indicator] - before if now[indicator] >= before else now[indicator]
            if delta:
                self.total[indicator] += delta
                grown.append(f"{delta} {name}")
        if grown:
            # Health messages are periodic: growth can belong to the previous surface too.
            log.warning("health update after %s: %s", when, ", ".join(grown))
        log.debug("health %s: CPU %s%%, speed %s Hz", when, now.get(HEALTH_CPU, "?"), now.get(HEALTH_SPEED, "?"))
        if HEALTH_CPU in now:
            self.max_cpu = max(self.max_cpu or 0, now[HEALTH_CPU])
        self.last = now

    def finish(self, wait: bool = True) -> None:
        """Wait for a health message that includes the end of the scan (unless the caller just
        did: wait=False), then report."""
        if wait:
            self.update("end of scan", wait=HEALTH_WAIT)
        self.report.health_received = self.received
        self.report.drops = {DROP_INDICATORS[i]: n for i, n in self.total.items() if n}
        self.report.max_cpu = self.max_cpu
        if (latency := self.last.get(HEALTH_MAX_LATENCY)) is not None:
            self.report.max_latency = latency / 1e6
        if not self.received:
            log.warning("no health messages from the sensor; dropped data could not be checked")
        elif lost := [f"{n} {DROP_INDICATORS[i]}" for i, n in self.total.items() if n]:
            # The sensor doesn't say why; CPU and latency show whether it fell behind.
            peaks = []
            if self.max_cpu is not None:
                peaks.append(f"CPU up to {self.max_cpu}%")
            if (latency := self.last.get(HEALTH_MAX_LATENCY)) is not None:
                peaks.append(f"processing latency up to {latency / 1e6:.3g} s")
            log.warning("data was lost during the scan: %s in total%s", ", ".join(lost), f" ({', '.join(peaks)})" if peaks else "")
        else:
            log.info("the sensor reported no dropped data")
        for indicator in sorted(self.last):
            old, new = self.first.get(indicator), self.last[indicator]
            if old != new:
                log.debug("health indicator %d (%s): %s -> %s", indicator, INDICATOR_NAMES.get(indicator, "undocumented"), old, new)


def check_link(health: dict[int, int]) -> str | None:
    """Warn when the network link is slower than gigabit full duplex (health indicator 2034)."""
    if (status := health.get(HEALTH_LINK)) is None:
        return None
    speed = next((name for bit, name in sorted(LINK_SPEEDS.items(), reverse=True) if status & bit), "no link or unknown speed")
    if status & 0x20:
        log.debug("network link: %s", speed)
    else:
        log.warning("network link is %s, not 1000 Mb/s full duplex: data may not keep up", speed)
    return speed


LIVE_LOG = "_live.log"  # the sensor's log, as shown in the web UI (classic firmware)


@dataclass
class LogEntry:
    id: int
    level: str  # element name: "Warning", "Error", "Info", ...
    text: str


def read_sensor_log(scanner: Scanner) -> list[LogEntry]:
    """Entries of the sensor's log: <Log><Warning id=".." value="..%s..."><Arg value=".."/>...</Log>."""
    entries = []
    for el in ET.fromstring(scanner.read_file(LIVE_LOG)):
        text = el.get("value", "")
        for arg in el.findall("Arg"):
            text = text.replace("%s", arg.get("value", ""), 1)
        entries.append(LogEntry(int(el.get("id", 0)), el.tag, text))
    return entries


class SensorLog:
    """Reports the sensor log entries added during a scan."""

    def __init__(self, scanner: Scanner, report: ScanReport | None = None):
        self.scanner = scanner
        self.report = report or ScanReport()
        entries = self._read()
        self.last_id = max((e.id for e in entries or []), default=0)
        self.available = entries is not None

    def _read(self) -> list[LogEntry] | None:
        try:
            return read_sensor_log(self.scanner)
        except (ScannerError, OSError, ET.ParseError, ValueError) as e:
            log.debug("could not read the sensor log: %s", e)
            return None

    def finish(self) -> None:
        if not self.available:
            return
        new = [e for e in self._read() or [] if e.id > self.last_id]
        # The sensor repeats some warnings; show each once with a count.
        for (level, text), n in Counter((e.level, e.text) for e in new).items():
            severity = logging.WARNING if level.lower() in ("warning", "error") else logging.INFO
            log.log(severity, "sensor log %s%s: %s", level.lower(), f" (x{n})" if n > 1 else "", text)
            self.report.log.append(f"{level.lower()}{f' (x{n})' if n > 1 else ''}: {text}")


def scan_pieces(
    scanner: Scanner,
    count: int,
    timeout: float,
    trigger: bool = False,
    before_surface: Callable[[], None] | None = None,
    received: list[Scan] | None = None,
    report: ScanReport | None = None,
) -> list[Scan]:
    """Start the sensor, receive `count` surfaces in a row and always try to stop it again.

    timeout applies to each surface. before_surface runs right before the first surface
    begins: between Start and the software trigger (sensor running, laser on), or before
    Start when there is no trigger. Surfaces are also appended to `received` as they
    arrive, so a caller can keep them when a later one fails; `report` receives what the
    sensor reported (drops, log). A failing stop is only logged, so it never hides the scan
    or the original error.
    """
    pieces = [] if received is None else received
    if before_surface and not trigger:
        before_surface()
    drops = DropWatch(scanner, report)
    sensor_log = SensorLog(scanner, report)
    scanner.start()
    try:
        if trigger:
            if before_surface:
                before_surface()
            scanner.trigger()
        for i in range(count):
            pieces.append(scanner.grab(timeout))
            if count > 1:
                log.info("received surface %d of %d (frame %s)", i + 1, count, pieces[-1].frame_index)
                drops.update(f"surface {i + 1}")
    finally:
        _stop(scanner)
        drops.finish()
        sensor_log.finish()
    return pieces


def _stop(scanner: Scanner) -> None:
    """Stop the sensor; a failure is only logged, so it never hides the scan or the original error."""
    try:
        scanner.stop()
    except (ScannerError, OSError) as e:
        log.warning("could not stop the sensor: %s", e)


def scan_once(
    scanner: Scanner,
    timeout: float,
    trigger: bool = False,
    before_surface: Callable[[], None] | None = None,
    report: ScanReport | None = None,
) -> Scan:
    """Start the sensor, wait for one surface and always try to stop it again (see scan_pieces)."""
    return scan_pieces(scanner, 1, timeout, trigger, before_surface, report=report)[0]


# Profile mode: the sensor sends each profile as it measures it; the tool builds the image
# (uniform profiles) or keeps the points (point clouds, uniform spacing off).

PROGRESS_EVERY = 5.0  # s between progress (and health) reports while receiving profiles


class ProfileFrames:
    """Profile batches placed by frame index: row = frame - first frame.

    A frame the sensor never sent leaves its row empty where it belongs. The shared part of
    ProfileImage and ProfileCloud: stopping after `rows`, and counting what arrived.
    """

    def __init__(self, rows: int | None = None):
        self.rows = rows  # stop after this many rows; None: until stopped
        self.first: int | None = None
        self.first_timestamp: float | None = None
        self.received = 0
        self.out_of_order = 0
        self.span = 0  # rows covered so far
        self.reached = -1  # latest row the stamps got to, also past the end (dropped frames included)
        self.batch_sizes: Counter[int] = Counter()
        self.last: tuple[int, float] | None = None  # latest frame index and its timestamp
        self.kept: list[np.ndarray] = []  # rows of each kept batch, in arrival order

    @property
    def done(self) -> bool:
        # A frame at or past the last row ends the scan, even if the last rows' own frames were
        # dropped: they are missing like any other, and later frames can't fill them.
        return self.rows is not None and self.reached >= self.rows - 1

    def _place(self, batch: ProfileBatch) -> np.ndarray:
        """Count the batch in; returns which of its profiles to keep (rows from 0 up to `rows`)."""
        if self.first is None:
            self.first, self.first_timestamp = int(batch.frame_indexes[0]), float(batch.timestamps_us[0])
        row = batch.frame_indexes.astype(np.int64) - self.first
        self.reached = max(self.reached, int(row.max()))
        keep = row >= 0
        self.out_of_order += int(np.count_nonzero(~keep))
        if self.rows is not None:
            keep &= row < self.rows
        if keep.any():
            self.kept.append(row[keep])
            self.span = max(self.span, int(row[keep].max()) + 1)
        self.received += len(row)
        self.batch_sizes[len(row)] += 1
        latest = int(np.argmax(batch.frame_indexes))
        if self.last is None or int(batch.frame_indexes[latest]) > self.last[0]:
            self.last = (int(batch.frame_indexes[latest]), float(batch.timestamps_us[latest]))
        return keep

    def measured_rate(self) -> float | None:
        """Frames per second from the stamps (first to latest profile)."""
        if self.first is None or self.last is None or self.first_timestamp is None:
            return None
        frames, seconds = self.last[0] - self.first, (self.last[1] - self.first_timestamp) / 1e6
        return frames / seconds if frames > 0 and seconds > 0 else None

    def _first_arrivals(self) -> tuple[int, list[np.ndarray], dict]:
        """Rows of the scan, per kept batch which profiles are the first for their row, and the details."""
        if not self.kept:
            raise ScannerError("no profiles received")
        rows = self.rows if self.done else self.span  # complete: missing last rows count as missing
        filled = np.zeros(rows, bool)
        first = []
        for row in self.kept:
            once = np.zeros(len(row), bool)  # a row twice in one batch: its first profile
            once[np.unique(row, return_index=True)[1]] = True
            first.append(~filled[row] & once)
            filled[row] = True
        details = {
            "rows": rows, "received": self.received, "missing_rows": int(rows - np.count_nonzero(filled)),
            "repeated": int(sum(len(n) - np.count_nonzero(n) for n in first)), "out_of_order": self.out_of_order,
            "batch_sizes": dict(sorted(self.batch_sizes.items())),
        }
        return rows, first, details


class ProfileImage(ProfileFrames):
    """Uniform profiles as a height (and intensity) image: one row per frame."""

    def __init__(self, rows: int | None = None):
        super().__init__(rows)
        self.parts: list[tuple[np.ndarray, np.ndarray | None]] = []  # heights, intensity of each kept batch
        self.geometry: tuple[float, float, float, float] | None = None  # x offset/resolution, z offset/resolution

    def add(self, batch: ProfileBatch) -> None:
        if not batch.uniform:
            raise ScannerError("point cloud profiles arrived (uniform spacing off); they become a point cloud, not an image")
        geometry = (batch.x_offset, batch.x_resolution, batch.z_offset, batch.z_resolution)
        if self.geometry is None:
            self.geometry = geometry
        elif not np.allclose(geometry, self.geometry):
            raise ScannerError(f"profile geometry changed during the scan: {geometry} after {self.geometry}")
        keep = self._place(batch)
        if keep.any():
            self.parts.append((batch.ranges[keep], None if batch.intensity is None else batch.intensity[keep]))

    def scan(self, y_resolution: float) -> tuple[Scan, dict]:
        """The image so far, and what happened (rows, missing and repeated frames, batching)."""
        rows, first, details = self._first_arrivals()
        assert self.geometry is not None
        width = self.parts[0][0].shape[1]
        heights = np.full((rows, width), INVALID_RANGE, np.int16)
        with_intensity = all(i is not None for _, i in self.parts)
        intensity = np.zeros((rows, width), np.uint8) if with_intensity else None
        for row, new, (h, i) in zip(self.kept, first, self.parts):
            heights[row[new]] = h[new]
            if intensity is not None and i is not None:
                intensity[row[new]] = i[new]
        x_offset, x_resolution, z_offset, z_resolution = self.geometry
        geometry = dict(x_resolution=x_resolution, y_resolution=y_resolution, x_offset=x_offset, y_offset=0.0)
        scan = Scan(
            heights=Grid(heights, z_resolution=z_resolution, z_offset=z_offset, **geometry),
            intensity=None if intensity is None else Grid(intensity, **geometry),
            frame_index=self.first,
            timestamp_us=self.first_timestamp,
        )
        return scan, {"uniform_spacing": True, **details}


@dataclass
class PointCloud:
    """A profile scan's points in mm: x and z as the sensor measured them, y = row * y spacing
    (negated when the layout is Reverse, so that the cloud has the normal handedness)."""

    x: np.ndarray  # (points,) float64
    y: np.ndarray
    z: np.ndarray
    row: np.ndarray  # (points,) row (frame - first frame) of each point
    intensity: np.ndarray | None = None  # (points,) uint8


class ProfileCloud(ProfileFrames):
    """Point cloud profiles (uniform spacing off), kept as the sensor sent them."""

    def __init__(self, rows: int | None = None):
        super().__init__(rows)
        self.parts: list[tuple[ProfileBatch, np.ndarray]] = []  # each kept batch and which profiles

    def add(self, batch: ProfileBatch) -> None:
        if batch.uniform:
            raise ScannerError("uniform profiles arrived (uniform spacing on); they become an image, not a point cloud")
        keep = self._place(batch)
        if keep.any():
            self.parts.append((batch, keep))

    def cloud(self, y_resolution: float, negate_y: bool = False) -> tuple[PointCloud, dict]:
        """Every valid point so far (each row's first profile), and what happened.

        negate_y: y = -row * y spacing. With the Reverse layout the sensor's data has the
        mirrored handedness (right for images, whose rows go down); negating y makes a 3D
        view show the scan as it is, with x still the sensor's (and the image columns').
        """
        _, first, details = self._first_arrivals()
        xs, ys, zs, rs, intensities = [], [], [], [], []
        for row, new, (batch, keep) in zip(self.kept, first, self.parts):
            points = batch.ranges[keep][new]
            xr, zr = points[..., 0], points[..., 1]
            valid = (xr != INVALID_RANGE) & (zr != INVALID_RANGE)
            r = np.broadcast_to(row[new][:, None], xr.shape)[valid]
            xs.append(batch.x_offset + batch.x_resolution * xr[valid].astype(np.float64))
            zs.append(batch.z_offset + batch.z_resolution * zr[valid].astype(np.float64))
            ys.append(r * (-y_resolution if negate_y else y_resolution))
            rs.append(r)
            if batch.intensity is not None:
                intensities.append(batch.intensity[keep][new][valid])
        intensity = np.concatenate(intensities) if len(intensities) == len(xs) else None
        cloud = PointCloud(np.concatenate(xs), np.concatenate(ys), np.concatenate(zs), np.concatenate(rs), intensity)
        return cloud, {"uniform_spacing": False, **details, "points": len(cloud.x), "y_negated": negate_y}


RECEIVE_SLICE = 0.2  # s: how often the receive loop looks for a stop request while waiting
DRAIN_QUIET = 0.3  # s without data after Stop: the sensor has sent what it still had
DRAIN_MAX = 10.0  # s at most to receive after Stop (should data keep coming)
COUNT_WAIT = 2.0  # s at most to wait for profiles the sensor's scan count says it sent
LATENCY_LOSS = 0.1  # s: processing latency at Stop above which the cut-off end is worth a warning


def latency_now(scanner: Scanner) -> float | None:
    """The sensor's processing latency (s), from the latest health message: how far behind
    taking frames its processing is (health indicator 21001)."""
    try:
        latency = scanner.health().get(HEALTH_LATENCY)
    except (ScannerError, OSError):
        return None
    return None if latency is None else latency / 1e6


def receive_counted(scanner: Scanner, image: ProfileFrames, count: int | None) -> None:
    """After Stop: receive until `image` has the `count` profiles the sensor says it sent (its
    scan count), for at most COUNT_WAIT s; warn about any that never came."""
    if count is None or image.received >= count:
        return
    log.debug("the sensor sent %d profiles, %d received: waiting for the rest", count, image.received)
    until = time.monotonic() + COUNT_WAIT
    while image.received < count and time.monotonic() < until:
        try:
            image.add(scanner.grab_profiles(RECEIVE_SLICE))
        except ScanTimeout:
            continue
    if image.received < count:
        log.warning("the sensor sent %d profiles but %d arrived: %d were lost on the way",
                    count, image.received, count - image.received)


STATE_CHECK_EVERY = 0.5  # s without data before (and between) asking whether the sensor still runs


def scan_profiles(
    scanner: Scanner,
    image: ProfileFrames,
    timeout: float,
    stop: threading.Event | None = None,
    before_surface: Callable[[], None] | None = None,
    report: ScanReport | None = None,
) -> str:
    """Start the sensor and add profiles to `image` until it has its rows or `stop` is set.

    Returns how the scan ended: "distance" (image has its rows), "stop" (`stop` was set) or
    "sensor stopped" (something else stopped the sensor: the web UI, another client).

    When `stop` is set, the sensor is stopped and the profiles still on their way are received
    too: until no data has come for DRAIN_QUIET s; then, if the sensor's scan count (in the
    first health message after Stop) says it sent more, until those have come too (see
    receive_counted). The sensor discards the frames it hasn't processed yet when it stops, so
    with a processing latency (CPU saturated) the scan loses its last `latency` s; the latency
    at Stop goes to the report. While no data comes, the sensor's state is checked every
    STATE_CHECK_EVERY s: no longer running means it was stopped elsewhere, and the scan ends
    the same way (without sending Stop). Still running but silent for `timeout` s is an error
    (ScanTimeout). The sensor is always stopped again, and `image` keeps what arrived, also
    when receiving fails.
    """
    if before_surface:
        before_surface()
    drops = DropWatch(scanner, report)
    sensor_log = SensorLog(scanner, report)
    scanner.start()
    stopped_at: float | None = None
    received_at_stop = 0
    ended = "distance"
    report = drops.report
    health_read = False
    try:
        started = last_report = last_data = last_check = time.monotonic()
        while not image.done:
            if stopped_at is None and stop is not None and stop.is_set():
                report.latency_at_stop = latency_now(scanner)
                stopped_at, ended = time.monotonic(), "stop"
                received_at_stop = image.received
                _stop(scanner)
            try:
                batch = scanner.grab_profiles(RECEIVE_SLICE)
            except ScanTimeout:
                now = time.monotonic()
                if stopped_at is not None:
                    if now - max(last_data, stopped_at) >= DRAIN_QUIET or now - stopped_at >= DRAIN_MAX:
                        break
                    continue
                if now - max(last_data, last_check) >= STATE_CHECK_EVERY:
                    last_check = now
                    if not scanner.is_running():  # stopped by something else
                        log.warning("the sensor was stopped by something else (the web UI or another client); "
                                    "keeping the %d profiles received", image.received)
                        report.latency_at_stop = latency_now(scanner)
                        stopped_at, ended = now, "sensor stopped"
                        received_at_stop = image.received
                        continue
                if now - last_data >= timeout:
                    raise ScanTimeout(
                        f"no profiles for {timeout:g} s while the sensor runs. Check the sensor's scan mode and "
                        "that the Gocator Ethernet output includes the profiles."
                    ) from None
                continue
            image.add(batch)
            last_data = now = time.monotonic()
            if now - last_report >= PROGRESS_EVERY:
                last_report = now
                log.info("received %d profiles (%d rows)", image.received, image.span)
                drops.update(f"{now - started:.0f} s")
        if stopped_at is not None:
            log.debug("after Stop: %d more profiles in %.3g s", image.received - received_at_stop,
                      time.monotonic() - stopped_at)
            drops.update("end of scan", wait=HEALTH_WAIT)
            health_read = True
            report.scan_count = drops.last.get(HEALTH_SCAN_COUNT)
            receive_counted(scanner, image, report.scan_count)
    finally:
        if stopped_at is None:
            _stop(scanner)
        drops.finish(wait=not health_read)
        sensor_log.finish()
    return ended


# Long scans as back-to-back fixed-length surfaces ("pieces"). The sensor lowers its
# maximum frame rate so that a whole surface fits in its memory, so a long surface caps
# the y resolution; shorter pieces raise the cap, and the tool joins them.

PIECE_SETTINGS = Settings(scan_mode="surface", trigger_source="time", surface_generation="fixed", surface_start="sequential")
MAX_PLAN_TRIES = 20


@dataclass
class PiecePlan:
    count: int
    length: float  # mm per piece
    frame_rate: float  # Hz
    distance: float  # mm; the joined scan is cropped to it when the pieces overshoot


def _check_cap(s: Settings, length: float, rate: float) -> None:
    cap = s.frame_rate_max
    if cap is not None and cap < rate - 1e-6:
        source = f", limited by {s.frame_rate_limit}" if s.frame_rate_limit else ""
        raise ScannerError(f"pieces of {length:g} mm allow at most {cap:g} Hz{source}; {rate:g} Hz was asked for")


def _fit_pieces(scanner: Scanner, distance: float, rate: float) -> tuple[int, float]:
    """The fewest equal pieces of `distance` whose frame rate cap reaches `rate`.

    Asks the sensor: writes a piece length and reads back the cap it computed. The next
    guess assumes the cap is inversely proportional to the length.
    """
    count, last_cap = 1, None
    for _ in range(MAX_PLAN_TRIES):
        length = distance / count
        scanner.apply_settings(Settings(surface_length=length))
        s = scanner.get_settings()
        cap = s.frame_rate_max
        if cap is None:
            raise ScannerError("the sensor does not report its maximum frame rate; use --max-piece or --piece")
        log.debug("%d piece(s) of %g mm: max frame rate %g Hz (%s)", count, length, cap, s.frame_rate_limit or "?")
        if cap >= rate - 1e-6:
            return count, length
        if s.frame_rate_limit == "camera" or (last_cap is not None and cap <= last_cap):
            # Shorter pieces don't help: the camera (exposure, active area) sets the cap.
            _check_cap(s, length, rate)
        last_cap = cap
        count = max(count + 1, math.ceil(count * rate / cap))
    raise ScannerError(f"no piece length found that allows {rate:g} Hz after {MAX_PLAN_TRIES} tries")


def plan_pieces(
    scanner: Scanner,
    distance: float,
    frame_rate: float | None = None,
    piece: float | None = None,
    max_piece: float | None = None,
) -> PiecePlan:
    """Configure the live job for `distance` mm as back-to-back fixed-length surfaces.

    The frame rate is `frame_rate`, or travel speed / x spacing (y spacing = x spacing).
    Piece length: `piece` exactly (the last piece overshoots), equal pieces of at most
    `max_piece`, or otherwise the fewest equal pieces whose frame rate cap allows the rate.
    """
    scanner.apply_settings(PIECE_SETTINGS)
    s = scanner.get_settings()
    if not s.travel_speed:
        raise ScannerError("a scan in pieces needs the travel speed (set it with --speed)")
    rate = frame_rate
    if rate is None:
        if not s.x_spacing:
            raise ScannerError("cannot read the x spacing to match; give --frame-rate")
        rate = s.travel_speed / s.x_spacing
    if piece is not None:
        count, length = math.ceil(distance / piece - 1e-9), piece
    elif max_piece is not None:
        count = math.ceil(distance / max_piece - 1e-9)
        length = distance / count
    else:
        count, length = _fit_pieces(scanner, distance, rate)
    if piece is not None or max_piece is not None:
        scanner.apply_settings(Settings(surface_length=length))
        _check_cap(scanner.get_settings(), length, rate)
    scanner.apply_settings(Settings(frame_rate=rate))
    plan = PiecePlan(count, length, rate, distance)
    log.info(
        "scanning %g mm as %d piece(s) of %g mm at %g Hz (y spacing %.4g mm)",
        distance, count, length, rate, s.travel_speed / rate,
    )
    return plan


@contextlib.contextmanager
def temporary_settings(scanner: Scanner) -> Generator[Callable[[], None], None, None]:
    """Undo the settings changes made inside the block, even on errors.

    Call the yielded function once the scan's settings are in place (before Start): what
    the sensor has then is what the scan set. At the end, a setting the scan changed goes
    back to its value from before the block, unless it no longer has the scan's value:
    then someone else (e.g. the web UI) changed it meanwhile, and it is kept.
    """
    before = scanner.get_settings()
    marked: list[Settings] = []

    def mark() -> None:
        marked[:] = [scanner.get_settings()]

    try:
        yield mark
    finally:
        try:
            _restore(scanner, before, marked[0] if marked else None)
        except (ScannerError, OSError) as e:
            log.warning("could not restore the settings: %s", e)


def _restore(scanner: Scanner, before: Settings, scanned: Settings | None) -> None:
    now = scanner.get_settings()
    scanned = scanned or now  # failed before the mark: nobody else had time to change anything
    restore = {}
    for f in fields(Settings):
        name = f.name
        if name in READ_ONLY or (name == "frame_rate" and before.max_frame_rate):
            continue  # at max frame rate, the rate follows the other settings
        old, ours, current = getattr(before, name), getattr(scanned, name), getattr(now, name)
        if old is None or same_value(old, ours):
            continue
        if same_value(current, ours):
            restore[name] = old
        else:
            log.warning("%s was changed during the scan (now %s); not restored", name, current)
    if restore:
        scanner.apply_settings(Settings(**restore))
        log.debug("restored %s", ", ".join(restore))


def check_pieces(pieces: list[Scan], frame_rate: float | None = None) -> list[str]:
    """Problems that make the joined scan suspect: missing pieces, gaps at the joints, unequal lengths.

    A surface's stamp numbers surfaces, not frames, so it only shows whole missing pieces.
    Gaps come from the timestamps: with time triggering a piece of `rows` rows lasts
    rows / frame_rate, so the next one should be that much later. (Profiles the sensor
    drops inside a surface still arrive, as rows without data: the health counters report those.)
    """
    problems = []
    lengths = {p.heights.data.shape[0] for p in pieces}
    if len(lengths) > 1:
        problems.append(f"pieces have different lengths: {sorted(lengths)} rows")
    for i, (a, b) in enumerate(itertools.pairwise(pieces), start=2):
        if a.frame_index is not None and b.frame_index is not None and b.frame_index - a.frame_index != 1:
            problems.append(f"piece {i} has surface index {b.frame_index}, piece {i - 1} {a.frame_index}: pieces missing?")
        if frame_rate and a.timestamp_us is not None and b.timestamp_us is not None:
            rows = b.heights.data.shape[0]
            frames = (b.timestamp_us - a.timestamp_us) * 1e-6 * frame_rate
            log.debug("piece %d: %.3f s after piece %d = %.1f frames, for %d rows", i, frames / frame_rate, i - 1, frames, rows)
            if abs(frames - rows) > max(2, 0.005 * rows):
                problems.append(
                    f"piece {i} came {frames / frame_rate:.3f} s after piece {i - 1}, {frames - rows:+.0f} frames "
                    f"from its {rows} rows: gap or overlap at the joint?"
                )
    return problems


def _stack(grids: list[Grid], rows: int | None) -> Grid:
    first = grids[0]
    for g in grids[1:]:
        if g.data.shape[1] != first.data.shape[1] or abs(g.x_resolution - first.x_resolution) > 1e-9 or abs(g.x_offset - first.x_offset) > 1e-9:
            raise ScannerError("pieces have different x geometry; cannot join them (save them with --output pieces)")
    data = np.concatenate([g.data for g in grids])
    return replace(first, data=data[:rows] if rows is not None else data)


def join_pieces(pieces: list[Scan], distance: float | None = None) -> Scan:
    """One scan from consecutive pieces, cropped to `distance` mm if they are longer."""
    first = pieces[0]
    rows = None
    if distance is not None and first.heights.y_resolution > 0:
        wanted = round(distance / first.heights.y_resolution)
        if wanted < sum(p.heights.data.shape[0] for p in pieces):
            rows = wanted
    scan = Scan(heights=_stack([p.heights for p in pieces], rows), frame_index=first.frame_index, timestamp_us=first.timestamp_us)
    if all(p.intensity is not None for p in pieces):
        scan.intensity = _stack([p.intensity for p in pieces if p.intensity is not None], rows)
    return scan

"""Scanner implementations, one package each, all implementing gocator.scanner.Scanner.

protocol: the Gocator Protocol (classic firmware) written directly in Python.
gosdk:    LMI's GoSdk (classic firmware) through ctypes; needs the SDK's libraries.
"""

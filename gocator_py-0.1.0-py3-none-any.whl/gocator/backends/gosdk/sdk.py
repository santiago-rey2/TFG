"""ctypes bindings for the part of LMI's GoSdk (classic firmware) this backend uses.

Types and signatures come from the GoSdk headers (GoSdk/*.h, kApi/kApiDef.h). The
libraries are built from the SDK source (see the README) and found through the
GOCATOR_GOSDK environment variable: the directory holding libGoSdk.so and libkApi.so.
"""

import ctypes
import os
from ctypes import POINTER, c_char_p, c_double, c_int16, c_int32, c_size_t, c_uint8, c_uint16, c_uint32, c_uint64, c_void_p
from pathlib import Path

from ...scanner import ScannerError

ENV_VAR = "GOCATOR_GOSDK"

HANDLE = c_void_p  # every GoSdk/kApi object (GoSystem, GoSensor, GoSetup, GoDataSet...)
STATUS = c_int32  # kStatus
BOOL = c_int32  # kBool

OK = 1
ERROR_TIMEOUT = -993
STATUS_NAMES = {
    0: "error", -1000: "invalid state", -999: "not found", -998: "invalid command",
    -997: "invalid parameter", -996: "not implemented", -994: "out of memory", -993: "timeout",
    -992: "incomplete", -991: "stream error", -990: "connection closed", -989: "incompatible version",
    -988: "aborted", -987: "already exists", -986: "network error", -984: "invalid format",
    -981: "busy", -980: "conflict", -978: "device error", -977: "full",
    -2001: "not authorized (sensor security is enabled; log-in is not implemented)",
}

ROLE_MAIN = 0
DEVICE_STATE_RUNNING = 1  # GoStates.sensorState
STATES_COUNT = 17  # GoStates: 17 32-bit fields
STATE_SENSOR, STATE_PLAYBACK_SOURCE = 0, 5

MSG_STAMP, MSG_UNIFORM_SURFACE, MSG_SURFACE_INTENSITY = 0, 8, 9  # GoDataMessageType
# Profiles. GoSdk numbers these differently from the wire (point cloud 5, uniform 6, intensity 7).
MSG_PROFILE_POINT_CLOUD, MSG_PROFILE_INTENSITY, MSG_UNIFORM_PROFILE = 5, 6, 7
OUTPUT_SOURCES = {  # GoOutputSource for the Ethernet output, by scan mode
    "surface": {"Surfaces": 4, "SurfaceIntensities": 7},
    "profile": {"Profiles": 3, "ProfileIntensities": 6},
}

LIVE_JOB = "_live.job"


class IpAddress(ctypes.Structure):  # kIpAddress
    _fields_ = [("version", c_int32), ("address", c_uint8 * 16)]


class AddressInfo(ctypes.Structure):  # GoAddressInfo
    _fields_ = [("useDhcp", BOOL), ("address", IpAddress), ("mask", IpAddress), ("gateway", IpAddress)]


class PortInfo(ctypes.Structure):  # GoPortInfo
    _fields_ = [("control", c_uint16), ("upgrade", c_uint16), ("web", c_uint16), ("data", c_uint16), ("health", c_uint16)]


class Stamp(ctypes.Structure):  # GoStamp
    _fields_ = [
        ("frameIndex", c_uint64), ("timestamp", c_uint64), ("encoder", ctypes.c_int64), ("encoderAtZ", ctypes.c_int64),
        ("status", c_uint64), ("id", c_uint32), ("reserved32u", c_uint32), ("reserved64u", c_uint64), ("ptpTime", c_uint64),
    ]


class Indicator(ctypes.Structure):  # GoIndicator
    _fields_ = [("id", c_uint32), ("instance", c_uint32), ("value", ctypes.c_int64)]


# Short names for the signature table below.
H, S, D, I32, U32 = HANDLE, c_size_t, c_double, c_int32, c_uint32
OUT = POINTER(HANDLE)

KAPI = {
    "kIpAddress_Parse": (STATUS, [POINTER(IpAddress), c_char_p]),
    "xkObject_DestroyImpl": (STATUS, [H, BOOL]),
}
GOSDK = {
    "GoSdk_Construct": (STATUS, [OUT]),
    "GoSystem_ConstructEx": (STATUS, [OUT, H]),  # Ex = without discovery
    "GoSystem_AddSensor": (STATUS, [H, POINTER(AddressInfo), POINTER(PortInfo), OUT]),
    "GoSystem_ClearData": (STATUS, [H]),
    "GoSystem_ReceiveData": (STATUS, [H, OUT, c_uint64]),
    "GoSystem_ReceiveHealth": (STATUS, [H, OUT, c_uint64]),
    "GoSensor_Id": (U32, [H]),
    "GoSensor_PartNumber": (STATUS, [H, c_char_p, S]),
    "GoSensor_FirmwareVersion": (U32, [H]),  # kVersion: major.minor.release.build, a byte each
    "GoHealthMsg_Count": (S, [H]),
    "GoHealthMsg_At": (POINTER(Indicator), [H, S]),
    "GoSensor_Connect": (STATUS, [H]),
    "GoSensor_EnableData": (STATUS, [H, BOOL]),
    "GoSensor_Start": (STATUS, [H]),
    "GoSensor_Stop": (STATUS, [H]),
    "GoSensor_Trigger": (STATUS, [H]),
    "GoSensor_Flush": (STATUS, [H]),
    "GoSensor_States": (STATUS, [H, POINTER(c_int32 * STATES_COUNT)]),
    "GoSensor_Setup": (H, [H]),
    "GoSensor_Output": (H, [H]),
    "GoSensor_Transform": (H, [H]),
    "GoSensor_FileCount": (S, [H]),
    "GoSensor_FileNameAt": (STATUS, [H, S, c_char_p, S]),
    "GoSensor_CopyFile": (STATUS, [H, c_char_p, c_char_p]),
    "GoSensor_UploadFile": (STATUS, [H, c_char_p, c_char_p]),
    "GoSensor_DownloadFile": (STATUS, [H, c_char_p, c_char_p]),
    "GoSensor_LoadedJob": (STATUS, [H, c_char_p, S, POINTER(BOOL)]),
    "GoSensor_SetDefaultJob": (STATUS, [H, c_char_p]),
    "GoSetup_ScanModeOptionCount": (S, [H]),
    "GoSetup_ScanModeOptionAt": (I32, [H, S]),
    "GoSetup_TriggerSourceOptionCount": (S, [H]),
    "GoSetup_TriggerSourceOptionAt": (I32, [H, S]),
    "GoSetup_MaxFrameRateEnabled": (BOOL, [H]),
    "GoSetup_EnableMaxFrameRate": (STATUS, [H, BOOL]),
    "GoSetup_SurfaceGeneration": (H, [H]),
    "GoOutput_Ethernet": (H, [H]),
    "GoEthernet_SourceCount": (S, [H, I32]),
    "GoEthernet_OptionCount": (S, [H, I32]),
    "GoEthernet_OptionAt": (U32, [H, I32, S]),
    "GoEthernet_AddSource": (STATUS, [H, I32, I32]),
    "GoDataSet_Count": (S, [H]),
    "GoDataSet_At": (H, [H, S]),
    "GoDataMsg_Type": (I32, [H]),
    "GoStampMsg_Count": (S, [H]),
    "GoStampMsg_At": (POINTER(Stamp), [H, S]),
    "GoUniformSurfaceMsg_RowAt": (POINTER(c_int16), [H, S]),
    "GoUniformProfileMsg_At": (POINTER(c_int16), [H, S]),
    "GoProfilePointCloudMsg_At": (POINTER(c_int16), [H, S]),  # kPoint16s: (x, z) pairs
    "GoProfileIntensityMsg_At": (POINTER(c_uint8), [H, S]),
    "GoSetup_UniformSpacingEnabled": (BOOL, [H]),
    "GoSetup_Layout": (H, [H]),
    "GoLayout_Orientation": (I32, [H]),
    "GoSetup_EnableUniformSpacing": (STATUS, [H, BOOL]),
    "GoSurfaceIntensityMsg_RowAt": (POINTER(c_uint8), [H, S]),
}
for port in ("Control", "Data", "Health"):
    GOSDK[f"GoSensor_Set{port}Port"] = (STATUS, [H, U32])
# Settings: getter, setter and, for numbers, limits. Enums are 32-bit ints.
for name in ("GoSetup_ScanMode", "GoSetup_TriggerSource", "GoSurfaceGeneration_GenerationType",
             "GoSurfaceGenerationFixedLength_StartTrigger"):
    obj, field = name.split("_")
    GOSDK[name] = (I32, [H])
    GOSDK[f"{obj}_Set{field}"] = (STATUS, [H, I32])
for name in ("GoSetup_FrameRate", "GoSurfaceGenerationFixedLength_Length"):
    obj, field = name.split("_")
    GOSDK[name] = GOSDK[f"{name}LimitMin"] = GOSDK[f"{name}LimitMax"] = (D, [H])
    GOSDK[f"{obj}_Set{field}"] = (STATUS, [H, D])
GOSDK["GoSetup_SpacingIntervalSystemValue"] = (D, [H, I32])
GOSDK["GoTransform_Speed"] = (D, [H])
GOSDK["GoTransform_SetSpeed"] = (STATUS, [H, D])
GOSDK["GoSetup_SpacingIntervalType"] = (I32, [H, I32])
for axis in "XZ":  # subsampling, per device role
    GOSDK[f"GoSetup_{axis}Subsampling"] = GOSDK[f"GoSetup_{axis}SubsamplingSystemValue"] = (U32, [H, I32])
    GOSDK[f"GoSetup_Set{axis}Subsampling"] = (STATUS, [H, I32, U32])
    GOSDK[f"GoSetup_{axis}SubsamplingOptionCount"] = (S, [H, I32])
    GOSDK[f"GoSetup_{axis}SubsamplingOptionAt"] = (U32, [H, I32, S])
    GOSDK[f"GoSetup_{axis}SubsamplingDefaultEnabled"] = GOSDK[f"GoSetup_{axis}SubsamplingDefaultEnabledUsed"] = (BOOL, [H, I32])
    GOSDK[f"GoSetup_Set{axis}SubsamplingDefaultEnabled"] = (STATUS, [H, I32, BOOL])
GOSDK["GoSetup_SetSpacingIntervalType"] = (STATUS, [H, I32, I32])
for field in ("Exposure", "SpacingInterval", "ActiveAreaX", "ActiveAreaZ", "ActiveAreaWidth", "ActiveAreaHeight"):  # per device role
    GOSDK[f"GoSetup_{field}"] = GOSDK[f"GoSetup_{field}LimitMin"] = GOSDK[f"GoSetup_{field}LimitMax"] = (D, [H, I32])
    GOSDK[f"GoSetup_Set{field}"] = (STATUS, [H, I32, D])
for msg, scaled in (("GoUniformSurfaceMsg", "XYZ"), ("GoSurfaceIntensityMsg", "XY")):
    GOSDK[f"{msg}_Length"] = GOSDK[f"{msg}_Width"] = (S, [H])
    for axis in scaled:
        GOSDK[f"{msg}_{axis}Resolution"] = (U32, [H])  # nm
        GOSDK[f"{msg}_{axis}Offset"] = (I32, [H])  # um
for msg, scaled in (("GoUniformProfileMsg", "XZ"), ("GoProfilePointCloudMsg", "XZ"), ("GoProfileIntensityMsg", "X")):
    GOSDK[f"{msg}_Count"] = GOSDK[f"{msg}_Width"] = (S, [H])
    for axis in scaled:
        GOSDK[f"{msg}_{axis}Resolution"] = (U32, [H])  # nm
        GOSDK[f"{msg}_{axis}Offset"] = (I32, [H])  # um


class Library:
    """libkApi + libGoSdk with their signatures, and the kApi/GoSdk assembly constructed."""

    def __init__(self, directory: str | os.PathLike | None = None):
        directory = directory or os.environ.get(ENV_VAR)
        if not directory:
            raise ScannerError(
                f"the GoSdk backend needs {ENV_VAR} set to the directory with libGoSdk.so and libkApi.so "
                "(see the README for building them)"
            )
        try:
            self.kapi = ctypes.CDLL(str(Path(directory) / "libkApi.so"))
            self.go = ctypes.CDLL(str(Path(directory) / "libGoSdk.so"))
        except OSError as e:
            raise ScannerError(f"cannot load the GoSdk libraries from {directory}: {e}") from e
        for lib, signatures in ((self.kapi, KAPI), (self.go, GOSDK)):
            for name, (restype, argtypes) in signatures.items():
                fn = getattr(lib, name)
                fn.restype, fn.argtypes = restype, argtypes
        self.assembly = HANDLE()
        check(self.go.GoSdk_Construct(ctypes.byref(self.assembly)), "initializing GoSdk")

    def destroy(self, obj: HANDLE) -> None:
        if obj:
            self.kapi.xkObject_DestroyImpl(obj, 0)


def check(status: int, what: str) -> None:
    if status != OK:
        raise ScannerError(f"{what} failed with status {status} ({STATUS_NAMES.get(status, 'unknown')})")


_library: Library | None = None


def library() -> Library:
    """Load the libraries once per process (GoSdk_Construct is process-wide)."""
    global _library
    if _library is None:
        _library = Library()
    return _library

"""GoSdk backend: LMI's C SDK for classic firmware (6.x), called through ctypes.

The SDK does the protocol work (connection, configuration caching, message parsing);
this class maps it to the Scanner interface. Unlike the protocol backend it has no raw
data log: the SDK owns the data socket.
"""

import ctypes
import logging
import tempfile
import time
import xml.etree.ElementTree as ET
from collections import Counter
from ctypes import byref
from pathlib import Path

import numpy as np

from ...scanner import Grid, ProfileBatch, Scan, ScannerError, ScanTimeout, Settings, check_range, choice_index, choice_name
from . import sdk
from .sdk import HANDLE, ROLE_MAIN, check

log = logging.getLogger(__name__)

CONTROL_PORT = 3190
UPGRADE_PORT = 3192
DATA_PORT = 3196
HEALTH_PORT = 3194

ENUMS = {  # Settings field: (object the SDK function takes, function name without Set)
    "scan_mode": ("setup", "GoSetup_ScanMode"),
    "trigger_source": ("setup", "GoSetup_TriggerSource"),
    "surface_generation": ("surface", "GoSurfaceGeneration_GenerationType"),
    "surface_start": ("surface", "GoSurfaceGenerationFixedLength_StartTrigger"),
}
OPTIONS = {  # enums the SDK lists the allowed values of
    "scan_mode": "GoSetup_ScanModeOption",
    "trigger_source": "GoSetup_TriggerSourceOption",
}
AREA = ("ActiveAreaX", "ActiveAreaZ", "ActiveAreaWidth", "ActiveAreaHeight")
LIVE_CONFIG = "_live.cfg"  # the live job's config.xml


def _setter(name: str) -> str:
    obj, field = name.split("_")
    return f"{obj}_Set{field}"


class GoSdkScanner:
    """Scanner on GoSdk. The sensor is added by address (no discovery), so custom ports work."""

    def __init__(
        self,
        host: str,
        control_port: int = CONTROL_PORT,
        data_port: int = DATA_PORT,
        health_port: int = HEALTH_PORT,
    ):
        self.host = host
        self.ports = {"Control": control_port, "Data": data_port, "Health": health_port}
        self._lib: sdk.Library | None = None
        self._system = HANDLE()
        self._sensor = HANDLE()
        self._indicators: dict[int, int] = {}  # latest health values

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *exc):
        self.close()

    @property
    def _go(self):
        if not self._lib or not self._sensor:
            raise ScannerError("not connected")
        return self._lib.go

    def connect(self) -> None:
        lib = self._lib = sdk.library()
        try:
            check(lib.go.GoSystem_ConstructEx(byref(self._system), None), "creating the GoSdk system")
            address = sdk.AddressInfo()
            check(lib.kapi.kIpAddress_Parse(byref(address.address), self.host.encode()), f"parsing address {self.host!r}")
            ports = sdk.PortInfo(
                control=self.ports["Control"], upgrade=UPGRADE_PORT, web=80,
                data=self.ports["Data"], health=self.ports["Health"],
            )
            check(lib.go.GoSystem_AddSensor(self._system, byref(address), byref(ports), byref(self._sensor)), "adding the sensor")
            # GoSdk 6.5's AddSensor stores the ports where Connect doesn't look; set them again.
            for name, port in self.ports.items():
                check(getattr(lib.go, f"GoSensor_Set{name}Port")(self._sensor, port), f"setting the {name.lower()} port")
            check(lib.go.GoSensor_Connect(self._sensor), f"connecting to the sensor at {self.host}")
            # Data is connected before any Start so the first surface cannot be missed. Per sensor:
            # the system's EnableData skips sensors from AddSensor. Data still reaches the system queue.
            check(lib.go.GoSensor_EnableData(self._sensor, 1), "opening the data channel")
            if self.states()[sdk.STATE_PLAYBACK_SOURCE] == 1:
                log.warning("sensor is in replay mode: data will come from the recording, not live")
        except BaseException:
            self.close()  # __exit__ does not run when __enter__ raises
            raise

    def close(self) -> None:
        if self._lib:
            # The sensor from AddSensor isn't owned by the system: destroy both (this disconnects).
            self._lib.destroy(self._sensor)
            self._lib.destroy(self._system)
        self._sensor, self._system = HANDLE(), HANDLE()

    def states(self) -> list[int]:
        states = (ctypes.c_int32 * sdk.STATES_COUNT)()
        check(self._go.GoSensor_States(self._sensor, byref(states)), "reading the sensor state")
        return list(states)

    def sensor_info(self) -> dict[str, str | int]:
        """Serial number, part number ("model") and, when known, firmware version.

        GoSdk only learns the firmware version from discovery, which this backend skips
        (the sensor is added by address), so it is usually missing here.
        """
        go = self._go
        part = ctypes.create_string_buffer(64)
        check(go.GoSensor_PartNumber(self._sensor, part, len(part)), "reading the part number")
        info: dict[str, str | int] = {"serial": go.GoSensor_Id(self._sensor), "model": part.value.decode("ascii", "replace")}
        if version := go.GoSensor_FirmwareVersion(self._sensor):
            info["firmware"] = ".".join(str(version >> shift & 0xFF) for shift in (24, 16, 8, 0))
        return info

    def health(self, wait: float = 0.0) -> dict[int, int]:
        """Latest health indicator values by id; with wait, first wait up to that long for a new message.

        GoSdk queues health messages from its own connection: read all queued ones, then
        (with wait) one that arrives after this call, and whatever came with it.
        """
        while self._receive_health(0):
            pass
        if wait > 0 and self._receive_health(wait):
            while self._receive_health(0):
                pass
        return dict(self._indicators)

    def _receive_health(self, timeout: float) -> bool:
        go, lib = self._go, self._lib
        assert lib
        dataset = HANDLE()
        if go.GoSystem_ReceiveHealth(self._system, byref(dataset), int(timeout * 1e6)) != sdk.OK:
            return False
        try:
            values: dict[int, int] = {}
            for i in range(go.GoDataSet_Count(dataset)):
                msg = go.GoDataSet_At(dataset, i)
                for j in range(go.GoHealthMsg_Count(msg)):
                    indicator = go.GoHealthMsg_At(msg, j).contents
                    values[indicator.id] = values.get(indicator.id, 0) + indicator.value
            self._indicators.update(values)
        finally:
            lib.destroy(dataset)
        return True

    def is_running(self) -> bool:
        return self.states()[sdk.STATE_SENSOR] == sdk.DEVICE_STATE_RUNNING

    def ensure_stopped(self) -> None:
        if self.is_running():
            log.info("stopping the running sensor")
            self.stop()

    def enable_outputs(self) -> None:
        """Make the Ethernet output send what the current scan mode produces (kept in the live job)."""
        self.ensure_stopped()
        try:
            if enabled := self._enable_outputs():
                log.info("enabled Ethernet outputs: %s", ", ".join(enabled))
                check(self._go.GoSensor_Flush(self._sensor), "writing the configuration")
        except ScannerError as e:
            log.warning("could not check the Ethernet outputs (%s); scanning with the job as it is", e)

    def start(self) -> None:
        self.enable_outputs()
        check(self._go.GoSystem_ClearData(self._system), "clearing old data")
        check(self._go.GoSensor_Start(self._sensor), "Start")

    def stop(self) -> None:
        check(self._go.GoSensor_Stop(self._sensor), "Stop")

    def trigger(self) -> None:
        check(self._go.GoSensor_Trigger(self._sensor), "Software Trigger")

    def _enable_outputs(self) -> list[str]:
        """Select the Ethernet outputs the current scan mode needs. Returns what was enabled."""
        go = self._go
        mode = choice_name("scan_mode", go.GoSetup_ScanMode(go.GoSensor_Setup(self._sensor)))
        ethernet = go.GoOutput_Ethernet(go.GoSensor_Output(self._sensor))
        enabled = []
        for tag, source in sdk.OUTPUT_SOURCES.get(mode, {}).items():
            if go.GoEthernet_SourceCount(ethernet, source) == 0 and go.GoEthernet_OptionCount(ethernet, source) > 0:
                option = go.GoEthernet_OptionAt(ethernet, source, 0)  # the main sensor
                check(go.GoEthernet_AddSource(ethernet, source, option), f"enabling the {tag} output")
                enabled.append(tag)
        return enabled

    # Files. Names are sensor file names, e.g. "_live.cfg", "myjob.job".

    def read_file(self, name: str) -> bytes:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "file"
            check(self._go.GoSensor_DownloadFile(self._sensor, name.encode(), str(path).encode()), f"reading {name}")
            return path.read_bytes()

    def write_file(self, name: str, data: bytes) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "file"
            path.write_bytes(data)
            check(self._go.GoSensor_UploadFile(self._sensor, str(path).encode(), name.encode()), f"writing {name}")

    def list_files(self, extension: str = "") -> list[str]:
        go, names = self._go, []
        buffer = ctypes.create_string_buffer(256)
        for i in range(go.GoSensor_FileCount(self._sensor)):
            check(go.GoSensor_FileNameAt(self._sensor, i, buffer, len(buffer)), "listing files")
            names.append(buffer.value.decode("ascii", "replace"))
        return [n for n in names if not extension or n.endswith("." + extension)]

    # Jobs

    def list_jobs(self) -> list[str]:
        return [name.removesuffix(".job") for name in self.list_files("job")]

    def loaded_job(self) -> tuple[str, bool]:
        buffer, changed = ctypes.create_string_buffer(256), sdk.BOOL()
        check(self._go.GoSensor_LoadedJob(self._sensor, buffer, len(buffer), byref(changed)), "reading the loaded job")
        return buffer.value.decode("ascii", "replace").removesuffix(".job"), bool(changed.value)

    def load_job(self, name: str) -> None:
        self.ensure_stopped()
        check(self._go.GoSensor_CopyFile(self._sensor, f"{name}.job".encode(), sdk.LIVE_JOB.encode()), f"loading job {name}")

    def save_job(self, name: str) -> None:
        check(self._go.GoSensor_CopyFile(self._sensor, sdk.LIVE_JOB.encode(), f"{name}.job".encode()), f"saving job {name}")

    def set_default_job(self, name: str) -> None:
        check(self._go.GoSensor_SetDefaultJob(self._sensor, f"{name}.job".encode()), f"setting default job {name}")

    # Settings

    def _objects(self) -> dict[str, HANDLE]:
        go = self._go
        setup = go.GoSensor_Setup(self._sensor)
        return {"setup": setup, "surface": go.GoSetup_SurfaceGeneration(setup), "transform": go.GoSensor_Transform(self._sensor)}

    def get_settings(self) -> Settings:
        go, obj = self._go, self._objects()
        setup, surface = obj["setup"], obj["surface"]
        x, z, width, height = (getattr(go, f"GoSetup_{name}")(setup, ROLE_MAIN) for name in AREA)
        s = Settings(
            frame_rate=go.GoSetup_FrameRate(setup),
            max_frame_rate=bool(go.GoSetup_MaxFrameRateEnabled(setup)),
            uniform_spacing=bool(go.GoSetup_UniformSpacingEnabled(setup)),
            orientation=choice_name("orientation", go.GoLayout_Orientation(go.GoSetup_Layout(setup))),
            frame_rate_max=go.GoSetup_FrameRateLimitMax(setup),
            frame_rate_limit=self._frame_rate_limit(),
            x_spacing=go.GoSetup_SpacingIntervalSystemValue(setup, ROLE_MAIN) or None,
            x_spacing_type=choice_name("x_spacing_type", go.GoSetup_SpacingIntervalType(setup, ROLE_MAIN)),
            x_subsampling=go.GoSetup_XSubsamplingSystemValue(setup, ROLE_MAIN) or None,
            z_subsampling=go.GoSetup_ZSubsamplingSystemValue(setup, ROLE_MAIN) or None,
            exposure=go.GoSetup_Exposure(setup, ROLE_MAIN),
            surface_length=go.GoSurfaceGenerationFixedLength_Length(surface),
            active_area=(x, z, width, height),
        )
        for field, (target, getter) in ENUMS.items():
            setattr(s, field, choice_name(field, getattr(go, getter)(obj[target])))
        for axis in "XZ":
            if getattr(go, f"GoSetup_{axis}SubsamplingDefaultEnabledUsed")(setup, ROLE_MAIN):
                enabled = getattr(go, f"GoSetup_{axis}SubsamplingDefaultEnabled")(setup, ROLE_MAIN)
                setattr(s, f"{axis.lower()}_subsampling_default", bool(enabled))
        if obj["transform"]:
            s.travel_speed = go.GoTransform_Speed(obj["transform"])
        return s

    def _frame_rate_limit(self) -> str | None:
        """What limits the frame rate. GoSdk parses this (maxSource) but has no getter for it."""
        try:
            el = ET.fromstring(self.read_file(LIVE_CONFIG)).find("Setup/Trigger/FrameRate")
        except (ScannerError, ET.ParseError) as e:
            log.debug("could not read the frame rate limit from %s: %s", LIVE_CONFIG, e)
            return None
        source = None if el is None else el.get("maxSource")
        return None if source is None else choice_name("frame_rate_limit", int(source))

    def _set_number(self, label: str, name: str, target: HANDLE, value: float, *role: int) -> None:
        go = self._go
        lo, hi = getattr(go, f"{name}LimitMin")(target, *role), getattr(go, f"{name}LimitMax")(target, *role)
        check_range(label, value, lo, hi)
        check(getattr(go, _setter(name))(target, *role, value), f"setting {label}")

    def apply_settings(self, settings: Settings) -> None:
        """Change the live job (lost on reboot unless saved with save_job) and check the result."""
        if split := settings.split_frame_rate():
            for part in split:
                self.apply_settings(part)
            return
        self.ensure_stopped()
        go, obj, s = self._go, self._objects(), settings
        setup = obj["setup"]
        for field, (target, getter) in ENUMS.items():
            if (name := getattr(s, field)) is None:
                continue
            allowed = None
            if field in OPTIONS:
                count = getattr(go, f"{OPTIONS[field]}Count")(setup)
                allowed = [getattr(go, f"{OPTIONS[field]}At")(setup, i) for i in range(count)]
            check(getattr(go, _setter(getter))(obj[target], choice_index(field, name, allowed)), f"setting {field}")

        if s.x_spacing_type is not None:
            spacing_type = choice_index("x_spacing_type", s.x_spacing_type)
            check(go.GoSetup_SetSpacingIntervalType(setup, ROLE_MAIN, spacing_type), "setting x_spacing_type")
        for axis in "XZ":
            name, has_default = f"{axis.lower()}_subsampling", getattr(go, f"GoSetup_{axis}SubsamplingDefaultEnabledUsed")(setup, ROLE_MAIN)
            if getattr(s, f"{name}_default"):
                if not has_default:
                    raise ScannerError(f"{name}: this sensor has no default subsampling")
                check(getattr(go, f"GoSetup_Set{axis}SubsamplingDefaultEnabled")(setup, ROLE_MAIN, 1), f"setting {name}_default")
            if (divisor := s.explicit_subsampling(axis.lower())) is not None:
                count = getattr(go, f"GoSetup_{axis}SubsamplingOptionCount")(setup, ROLE_MAIN)
                options = [getattr(go, f"GoSetup_{axis}SubsamplingOptionAt")(setup, ROLE_MAIN, i) for i in range(count)]
                if options and divisor not in options:
                    raise ScannerError(f"{name}: 1/{divisor} is not available (available: {', '.join(f'1/{o}' for o in options)})")
                if has_default:  # an explicit value only counts with the default off
                    check(getattr(go, f"GoSetup_Set{axis}SubsamplingDefaultEnabled")(setup, ROLE_MAIN, 0), f"setting {name}_default")
                check(getattr(go, f"GoSetup_Set{axis}Subsampling")(setup, ROLE_MAIN, divisor), f"setting {name}")

        if (spacing := s.custom_x_spacing()) is not None:
            custom = choice_index("x_spacing_type", "custom")
            check(go.GoSetup_SetSpacingIntervalType(setup, ROLE_MAIN, custom), "setting x_spacing_type")
            self._set_number("x_spacing", "GoSetup_SpacingInterval", setup, spacing, ROLE_MAIN)

        if s.uniform_spacing is not None:
            check(go.GoSetup_EnableUniformSpacing(setup, int(s.uniform_spacing)), "setting uniform_spacing")

        max_rate = s.max_frame_rate_to_apply()
        if max_rate is not None:
            check(go.GoSetup_EnableMaxFrameRate(setup, int(max_rate)), "setting max_frame_rate")
        if s.frame_rate is not None and not max_rate:
            self._set_number("frame_rate", "GoSetup_FrameRate", setup, s.frame_rate)
        if s.exposure is not None:
            self._set_number("exposure", "GoSetup_Exposure", setup, s.exposure, ROLE_MAIN)
        if s.surface_length is not None:
            self._set_number("surface_length", "GoSurfaceGenerationFixedLength_Length", obj["surface"], s.surface_length)

        if s.active_area == "max":
            limits = ("LimitMin", "LimitMin", "LimitMax", "LimitMax")  # x, z: lowest; width, height: largest
            area = [getattr(go, f"GoSetup_{name}{limit}")(setup, ROLE_MAIN) for name, limit in zip(AREA, limits)]
        elif isinstance(s.active_area, tuple):
            area = list(s.active_area)
        else:
            area = []
        for name, value in zip(AREA, area):
            self._set_number(f"active area {name.removeprefix('ActiveArea')}", f"GoSetup_{name}", setup, value, ROLE_MAIN)

        if s.travel_speed is not None:
            if not obj["transform"]:
                raise ScannerError("the sensor has no transform to store the travel speed in")
            check(go.GoTransform_SetSpeed(obj["transform"], s.travel_speed), "setting travel_speed")

        check(go.GoSensor_Flush(self._sensor), "writing the configuration")
        # The sensor may adjust values (e.g. a frame rate above what the exposure allows).
        for difference in settings.differences(self.get_settings()):
            log.warning("sensor adjusted %s", difference)

    # Data

    def _next_dataset(self, timeout: float, wanted: tuple[int, ...], what: str, build):
        """build(messages by type) on the next data set containing one of the `wanted` types.

        Other data sets are skipped. build must copy what it needs: the messages are freed
        with the data set.
        """
        go, lib = self._go, self._lib
        assert lib
        deadline = time.monotonic() + timeout
        seen: Counter[int] = Counter()
        while (remaining := deadline - time.monotonic()) > 0:
            dataset = HANDLE()
            status = go.GoSystem_ReceiveData(self._system, byref(dataset), int(remaining * 1e6))
            if status == sdk.ERROR_TIMEOUT:
                break
            check(status, "receiving data")
            try:
                messages = {}
                for i in range(go.GoDataSet_Count(dataset)):
                    msg = go.GoDataSet_At(dataset, i)
                    msg_type = go.GoDataMsg_Type(msg)
                    seen[msg_type] += 1
                    messages.setdefault(msg_type, msg)
                if any(t in messages for t in wanted):
                    return build(messages)
            finally:
                lib.destroy(dataset)
        hint = f"GoSdk message types received: {dict(seen)}" if seen else "no data received"
        raise ScanTimeout(
            f"no {what} within {timeout:g} s ({hint}). Check the sensor's scan mode and that the "
            f"Gocator Ethernet output includes the {what}."
        )

    def grab(self, timeout: float) -> Scan:
        """Wait for the next data set that contains a Uniform Surface; others are skipped."""
        return self._next_dataset(timeout, (sdk.MSG_UNIFORM_SURFACE,), "surface", self._scan)

    def grab_profiles(self, timeout: float) -> ProfileBatch:
        """Wait for the next data set with profiles (uniform or point cloud)."""
        wanted = (sdk.MSG_UNIFORM_PROFILE, sdk.MSG_PROFILE_POINT_CLOUD)
        return self._next_dataset(timeout, wanted, "profiles", self._profiles)

    def _profiles(self, messages: dict[int, HANDLE]) -> ProfileBatch:
        go = self._go
        uniform = sdk.MSG_UNIFORM_PROFILE in messages
        prefix = "GoUniformProfileMsg" if uniform else "GoProfilePointCloudMsg"
        msg = messages[sdk.MSG_UNIFORM_PROFILE if uniform else sdk.MSG_PROFILE_POINT_CLOUD]

        def get(name):
            return getattr(go, f"{prefix}_{name}")(msg)

        count, width = get("Count"), get("Width")
        shape = (count, width) if uniform else (count, width, 2)
        ranges = np.ctypeslib.as_array(getattr(go, f"{prefix}_At")(msg, 0), shape=shape).astype(np.int16, copy=True)
        stamps = messages.get(sdk.MSG_STAMP)
        n = go.GoStampMsg_Count(stamps) if stamps else 0
        if n != count:
            raise ScannerError(f"{count} profiles but {n} stamps in a data set")
        rows = [go.GoStampMsg_At(stamps, i).contents for i in range(n)]
        batch = ProfileBatch(
            np.array([s.frameIndex for s in rows], np.uint64), np.array([s.timestamp / 1.024 for s in rows]), ranges,
            get("XResolution") / 1e6, get("ZResolution") / 1e6, get("XOffset") / 1e3, get("ZOffset") / 1e3,  # nm, um -> mm
        )
        if (intensity := messages.get(sdk.MSG_PROFILE_INTENSITY)) and (
            go.GoProfileIntensityMsg_Count(intensity), go.GoProfileIntensityMsg_Width(intensity)
        ) == (count, width):
            data = go.GoProfileIntensityMsg_At(intensity, 0)
            batch.intensity = np.ctypeslib.as_array(data, shape=(count, width)).astype(np.uint8, copy=True)
        return batch

    def _scan(self, messages: dict[int, HANDLE]) -> Scan:
        """Copy the data out of the SDK's messages (they are freed with the data set)."""
        go = self._go

        def grid(prefix: str, msg: HANDLE, dtype, with_z: bool) -> Grid:
            def get(name):
                return getattr(go, f"{prefix}_{name}")(msg)

            length, width = get("Length"), get("Width")
            data = np.ctypeslib.as_array(getattr(go, f"{prefix}_RowAt")(msg, 0), shape=(length, width))
            z = dict(z_resolution=get("ZResolution") / 1e6, z_offset=get("ZOffset") / 1e3) if with_z else {}
            return Grid(
                data.astype(dtype, copy=True),
                x_resolution=get("XResolution") / 1e6, y_resolution=get("YResolution") / 1e6,  # nm -> mm
                x_offset=get("XOffset") / 1e3, y_offset=get("YOffset") / 1e3,  # um -> mm
                **z,
            )

        scan = Scan(heights=grid("GoUniformSurfaceMsg", messages[sdk.MSG_UNIFORM_SURFACE], np.int16, True))
        if sdk.MSG_SURFACE_INTENSITY in messages:
            scan.intensity = grid("GoSurfaceIntensityMsg", messages[sdk.MSG_SURFACE_INTENSITY], np.uint8, False)
        if sdk.MSG_STAMP in messages and go.GoStampMsg_Count(messages[sdk.MSG_STAMP]):
            stamp = go.GoStampMsg_At(messages[sdk.MSG_STAMP], 0).contents
            scan.frame_index, scan.timestamp_us = stamp.frameIndex, stamp.timestamp / 1.024
        return scan

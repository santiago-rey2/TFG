"""Gocator Protocol client for classic firmware (6.x), written directly in Python.

Byte layouts come from the Gocator Line Profile Sensors user manual (chapter "Gocator
Protocol") and were checked against the GoSdk C source (Messages/GoDataTypes.c).

Control channel (TCP 3190): command = [size u32][id u16][payload],
                            reply   = [size u32][id u16][status s32][payload].
Data channel (TCP 3196):    message = [size u32][control u16][body]; control bit 15
                            marks the last message of a group, bits 0-14 the type.
Health channel (TCP 3194):  the same framing; type 0 = Health Result (indicator values).
All values are little endian.
"""

import logging
import socket
import struct
import threading
import time
import xml.etree.ElementTree as ET
from collections import Counter
from typing import BinaryIO

import numpy as np

from . import config
from ...scanner import Grid, ProfileBatch, Scan, ScannerError, ScanTimeout, Settings

log = logging.getLogger(__name__)

CONTROL_PORT = 3190
DATA_PORT = 3196
HEALTH_PORT = 3194

CMD_STOP = 0x1001
CMD_WRITE_FILE = 0x1006
CMD_READ_FILE = 0x1007
CMD_START = 0x100D
CMD_LIST_FILES = 0x101A
CMD_COPY_FILE = 0x101B
CMD_GET_SYSTEM_INFO_2 = 0x4010
CMD_SET_DEFAULT_JOB = 0x4101
CMD_SOFTWARE_TRIGGER = 0x4510
CMD_GET_LOADED_JOB = 0x4512
CMD_GET_STATES = 0x4525

LIVE_JOB = "_live.job"
LIVE_CONFIG = "_live.cfg"  # the live job's config.xml, as the SDK reads/writes it
LIVE_TRANSFORM = "_live.tfm"  # holds the travel speed

MSG_HEALTH = 0  # on the health channel
MSG_STAMP = 1
MSG_PROFILE_POINT_CLOUD = 5  # profiles without uniform spacing: (x, z) pairs
MSG_UNIFORM_PROFILE = 6
MSG_PROFILE_INTENSITY = 7
MSG_UNIFORM_SURFACE = 8
MSG_SURFACE_INTENSITY = 9
LAST_MESSAGE_FLAG = 0x8000

STATUS_OK = 1
STATUS_NAMES = {
    0: "failed",
    -1000: "invalid state",
    -999: "item not found",
    -998: "invalid command",
    -997: "invalid parameter",
    -996: "not supported",
    -992: "simulation buffer empty",
}

# Get States reply: index of each value in the list of s32 state variables.
STATE_SENSOR = 0  # -1 conflict, 0 ready, 1 running
STATE_LOGIN = 1  # 0 no user
STATE_PLAYBACK_SOURCE = 5  # 0 live, 1 recorded (replay mode)
STATE_SECURITY_LEVEL = 15  # 0 no security
SENSOR_RUNNING = 1

COMMAND_TIMEOUT = 15.0  # s; Start can take a few seconds

# Attribute layouts, read from just after each message's u16 attributeSize field.
SURFACE_ATTRS = struct.Struct("<5I3i")  # length, width, x/y/z scale (nm), x/y/z offset (um)
INTENSITY_ATTRS = struct.Struct("<4I2i")  # length, width, x/y scale (nm), x/y offset (um)
PROFILE_ATTRS = struct.Struct("<4I2i")  # count, width, x/z scale (nm), x/z offset (um)
PROFILE_INTENSITY_ATTRS = struct.Struct("<3Ii")  # count, width, x scale (nm), x offset (um)
STAMP_HEADER = struct.Struct("<IHBB")  # count, stamp size, source, reserved
STAMP = struct.Struct("<QQ")  # frameIndex, timestamp (first fields of each stamp)
SYSTEM_INFO = struct.Struct("<I4s32s4B")  # serial, IP, part number, firmware version (after a u16 size)
HEALTH_HEADER = struct.Struct("<IB3x")  # count, source (0 main, 1 buddy), reserved
INDICATOR = struct.Struct("<IIq")  # id, instance, value


def file_name(name: str) -> bytes:
    """A file name as the protocol's fixed char[64] field (null padded)."""
    data = name.encode("ascii")
    if len(data) >= 64:
        raise ScannerError(f"file name too long (max 63 characters): {name}")
    return data.ljust(64, b"\0")


def decode_name(field: bytes) -> str:
    return field.split(b"\0", 1)[0].decode("ascii", "replace")


def recv_exactly(sock: socket.socket, n: int) -> bytes:
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(min(n - len(buf), 1 << 20))
        if not chunk:
            raise ScannerError("sensor closed the connection")
        buf += chunk
    return bytes(buf)


def _grid_data(body: bytes, attr_size: int, length: int, width: int, dtype: str, values: int = 1) -> np.ndarray:
    # attributeSize does not count its own 2 bytes (GoSdk reads it with includeSize=kFALSE),
    # so the data starts right after the attributes; unknown newer attributes are skipped.
    start = 2 + attr_size
    count = length * width * values
    if len(body) - start < count * np.dtype(dtype).itemsize:
        raise ScannerError(
            f"message too short: {len(body)} bytes, attributes {attr_size}, {length}x{width}x{values} {dtype}"
        )
    shape = (length, width, values) if values > 1 else (length, width)
    return np.frombuffer(body, dtype, count, start).reshape(shape).copy()


def parse_uniform_surface(body: bytes) -> Grid:
    """Parse a Uniform Surface message (type 8); body excludes the 6-byte header."""
    (attr_size,) = struct.unpack_from("<H", body)
    length, width, xs, ys, zs, xo, yo, zo = SURFACE_ATTRS.unpack_from(body, 2)
    return Grid(
        data=_grid_data(body, attr_size, length, width, "<i2"),
        x_resolution=xs / 1e6,
        y_resolution=ys / 1e6,
        x_offset=xo / 1e3,
        y_offset=yo / 1e3,
        z_resolution=zs / 1e6,
        z_offset=zo / 1e3,
    )


def parse_surface_intensity(body: bytes) -> Grid:
    """Parse a Surface Intensity message (type 9); body excludes the 6-byte header."""
    (attr_size,) = struct.unpack_from("<H", body)
    length, width, xs, ys, xo, yo = INTENSITY_ATTRS.unpack_from(body, 2)
    return Grid(
        data=_grid_data(body, attr_size, length, width, "u1"),
        x_resolution=xs / 1e6,
        y_resolution=ys / 1e6,
        x_offset=xo / 1e3,
        y_offset=yo / 1e3,
    )


def parse_stamp(body: bytes) -> tuple[int, float]:
    """Return (frame index, timestamp in us) of the first stamp in a Stamp message (type 1)."""
    count, _, _, _ = STAMP_HEADER.unpack_from(body)
    if count == 0:
        raise ScannerError("stamp message without stamps")
    frame_index, timestamp = STAMP.unpack_from(body, STAMP_HEADER.size)
    return frame_index, timestamp / 1.024


def parse_stamps(body: bytes) -> tuple[np.ndarray, np.ndarray]:
    """Frame indexes and timestamps (us) of every stamp in a Stamp message (one per profile)."""
    count, size, _, _ = STAMP_HEADER.unpack_from(body)
    if len(body) < STAMP_HEADER.size + count * size or size < STAMP.size:
        raise ScannerError(f"stamp message too short: {len(body)} bytes for {count} stamps of {size}")
    stamps = np.ndarray((count,), np.dtype([("frame", "<u8"), ("time", "<u8")]), body, STAMP_HEADER.size, (size,))
    return stamps["frame"].copy(), stamps["time"] / 1.024


def profiles_from_group(group: dict[int, bytes]) -> ProfileBatch:
    """Build a ProfileBatch from one message group with a Uniform Profile or Profile Point Cloud."""
    msg_type = MSG_UNIFORM_PROFILE if MSG_UNIFORM_PROFILE in group else MSG_PROFILE_POINT_CLOUD
    body = group[msg_type]
    (attr_size,) = struct.unpack_from("<H", body)
    count, width, xs, zs, xo, zo = PROFILE_ATTRS.unpack_from(body, 2)
    values = 1 if msg_type == MSG_UNIFORM_PROFILE else 2
    ranges = _grid_data(body, attr_size, count, width, "<i2", values)
    if MSG_STAMP in group:
        frames, times = parse_stamps(group[MSG_STAMP])
    else:
        frames, times = np.zeros(0, np.uint64), np.zeros(0)
    if len(frames) != count:
        raise ScannerError(f"{count} profiles but {len(frames)} stamps in a message group")
    batch = ProfileBatch(frames, times, ranges, xs / 1e6, zs / 1e6, xo / 1e3, zo / 1e3)
    if MSG_PROFILE_INTENSITY in group:
        body = group[MSG_PROFILE_INTENSITY]
        (attr_size,) = struct.unpack_from("<H", body)
        icount, iwidth, _, _ = PROFILE_INTENSITY_ATTRS.unpack_from(body, 2)
        if (icount, iwidth) == (count, width):
            batch.intensity = _grid_data(body, attr_size, icount, iwidth, "u1")
    return batch


def parse_health(body: bytes) -> dict[int, int]:
    """Indicator values of a Health Result (type 0), by id; instances are summed."""
    count, _ = HEALTH_HEADER.unpack_from(body)
    count = min(count, (len(body) - HEALTH_HEADER.size) // INDICATOR.size)
    values: dict[int, int] = {}
    for i in range(count):
        indicator, _, value = INDICATOR.unpack_from(body, HEALTH_HEADER.size + i * INDICATOR.size)
        values[indicator] = values.get(indicator, 0) + value
    return values


def scan_from_group(group: dict[int, bytes]) -> Scan:
    """Build a Scan from one message group, keyed by message type."""
    scan = Scan(heights=parse_uniform_surface(group[MSG_UNIFORM_SURFACE]))
    if MSG_SURFACE_INTENSITY in group:
        scan.intensity = parse_surface_intensity(group[MSG_SURFACE_INTENSITY])
    if MSG_STAMP in group:
        scan.frame_index, scan.timestamp_us = parse_stamp(group[MSG_STAMP])
    return scan


class ProtocolScanner:
    """Scanner over the classic Gocator Protocol.

    raw_log: optional binary file that receives every data-channel message verbatim,
    so a real capture can be replayed later through the mock sensor.
    """

    def __init__(
        self,
        host: str,
        control_port: int = CONTROL_PORT,
        data_port: int = DATA_PORT,
        raw_log: BinaryIO | None = None,
        health_port: int = HEALTH_PORT,
    ):
        self.host = host
        self.control_port = control_port
        self.data_port = data_port
        self.health_port = health_port
        self.raw_log = raw_log
        self._control: socket.socket | None = None
        self._data: socket.socket | None = None
        # Received but not yet used: bytes of an incomplete message, messages of an incomplete
        # group. Kept across calls, so a timeout never loses data or the message boundaries.
        self._rx = bytearray()
        self._group: dict[int, bytes] = {}
        self._health: socket.socket | None = None
        self._indicators: dict[int, int] = {}  # latest health values
        self._health_count = 0  # health messages received
        self._health_changed = threading.Condition()

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *exc):
        self.close()

    def connect(self) -> None:
        try:
            self._control = socket.create_connection((self.host, self.control_port), COMMAND_TIMEOUT)
            # Data is connected before any Start so the first surface cannot be missed.
            self._data = socket.create_connection((self.host, self.data_port), COMMAND_TIMEOUT)
        except OSError as e:
            self.close()
            raise ScannerError(f"cannot connect to sensor at {self.host}: {e}") from e
        try:
            self._health = socket.create_connection((self.host, self.health_port), COMMAND_TIMEOUT)
            self._health.settimeout(None)
            threading.Thread(target=self._read_health, args=(self._health,), daemon=True).start()
        except OSError as e:
            log.warning("no health channel (%s); dropped data will not be reported", e)

        try:
            states = self.states()
            if len(states) > STATE_SECURITY_LEVEL and states[STATE_SECURITY_LEVEL] != 0 and states[STATE_LOGIN] == 0:
                raise ScannerError("sensor has security enabled; log-in is not implemented yet")
        except BaseException:
            self.close()  # __exit__ does not run when __enter__ raises
            raise
        if len(states) > STATE_PLAYBACK_SOURCE and states[STATE_PLAYBACK_SOURCE] == 1:
            log.warning("sensor is in replay mode: data will come from the recording, not live")

    def close(self) -> None:
        for sock in (self._control, self._data, self._health):
            if sock:
                sock.close()
        self._control = self._data = self._health = None

    def _read_health(self, sock: socket.socket) -> None:
        """Keep the latest health values (the sensor sends them periodically) until closed."""
        try:
            while True:
                size, control = struct.unpack("<IH", recv_exactly(sock, 6))
                body = recv_exactly(sock, size - 6)
                if control & 0x7FFF == MSG_HEALTH:
                    values = parse_health(body)
                    with self._health_changed:
                        self._indicators.update(values)
                        self._health_count += 1
                        self._health_changed.notify_all()
        except (ScannerError, OSError, struct.error):
            return  # closed

    def health(self, wait: float = 0.0) -> dict[int, int]:
        """Latest health indicator values by id; with wait, first wait up to that long for a new message."""
        with self._health_changed:
            if wait > 0 and self._health:
                count = self._health_count
                self._health_changed.wait_for(lambda: self._health_count > count, wait)
            return dict(self._indicators)

    def command(self, command_id: int, payload: bytes = b"") -> bytes:
        """Send a control command, check its status and return the reply payload."""
        if not self._control:
            raise ScannerError("not connected")
        self._control.sendall(struct.pack("<IH", 6 + len(payload), command_id) + payload)
        size, reply_id, status = struct.unpack("<IHi", recv_exactly(self._control, 10))
        reply = recv_exactly(self._control, size - 10)
        if reply_id != command_id:
            raise ScannerError(f"reply 0x{reply_id:04X} does not match command 0x{command_id:04X}")
        if status != STATUS_OK:
            name = STATUS_NAMES.get(status, "unknown")
            raise ScannerError(f"command 0x{command_id:04X} failed with status {status} ({name})")
        return reply

    def states(self) -> list[int]:
        reply = self.command(CMD_GET_STATES)
        (count,) = struct.unpack_from("<I", reply)
        count = min(count, (len(reply) - 4) // 4)
        return list(struct.unpack_from(f"<{count}i", reply, 4))

    def sensor_info(self) -> dict[str, str | int]:
        """Serial number, part number ("model") and firmware version (Get System Info v2)."""
        serial, _, part, *version = SYSTEM_INFO.unpack_from(self.command(CMD_GET_SYSTEM_INFO_2), 2)
        return {"serial": serial, "model": decode_name(part), "firmware": ".".join(map(str, version))}

    def is_running(self) -> bool:
        return self.states()[STATE_SENSOR] == SENSOR_RUNNING

    def ensure_stopped(self) -> None:
        # Configuration can only change in the Ready state (GoSdk: GoState_IsConfigurable).
        if self.is_running():
            log.info("stopping the running sensor")
            self.command(CMD_STOP)

    def enable_outputs(self) -> None:
        """Make the Ethernet output send what the current scan mode produces (kept in the live job)."""
        self.ensure_stopped()
        try:
            cfg = config.parse(self.read_file(LIVE_CONFIG))
            if enabled := config.enable_outputs(cfg):
                log.info("enabled Ethernet outputs: %s", ", ".join(enabled))
                self.write_file(LIVE_CONFIG, config.serialize(cfg))
        except ScannerError as e:
            log.warning("could not check the Ethernet outputs (%s); scanning with the job as it is", e)

    def start(self) -> None:
        self.enable_outputs()
        self._discard_data()
        self.command(CMD_START)

    def _discard_data(self) -> None:
        """Drop data left from before (the end of a previous scan on this connection), so
        what the next grab returns is from the new Start. (GoSdk: GoSystem_ClearData.)"""
        self._rx.clear()
        self._group = {}
        if not self._data:
            return
        self._data.setblocking(False)
        try:
            while self._data.recv(1 << 20):
                pass
        except (BlockingIOError, InterruptedError):
            pass  # nothing more waiting
        finally:
            self._data.setblocking(True)

    def stop(self) -> None:
        self.command(CMD_STOP)

    def trigger(self) -> None:
        self.command(CMD_SOFTWARE_TRIGGER)

    # Files. Names are sensor file names, e.g. "_live.cfg", "myjob.job", "myjob.job/config.xml".

    def read_file(self, name: str) -> bytes:
        reply = self.command(CMD_READ_FILE, file_name(name))
        (length,) = struct.unpack_from("<I", reply)
        return reply[4 : 4 + length]

    def write_file(self, name: str, data: bytes) -> None:
        self.command(CMD_WRITE_FILE, file_name(name) + struct.pack("<I", len(data)) + data)

    def copy_file(self, source: str, destination: str) -> None:
        self.command(CMD_COPY_FILE, file_name(source) + file_name(destination))

    def list_files(self, extension: str = "") -> list[str]:
        reply = self.command(CMD_LIST_FILES, file_name(extension))
        (count,) = struct.unpack_from("<I", reply)
        return [decode_name(reply[4 + 64 * i : 4 + 64 * (i + 1)]) for i in range(count)]

    # Jobs

    def list_jobs(self) -> list[str]:
        return [name.removesuffix(".job") for name in self.list_files("job")]

    def loaded_job(self) -> tuple[str, bool]:
        reply = self.command(CMD_GET_LOADED_JOB)
        return decode_name(reply[:64]).removesuffix(".job"), bool(reply[64])

    def load_job(self, name: str) -> None:
        self.ensure_stopped()
        self.copy_file(f"{name}.job", LIVE_JOB)

    def save_job(self, name: str) -> None:
        self.copy_file(LIVE_JOB, f"{name}.job")

    def set_default_job(self, name: str) -> None:
        self.command(CMD_SET_DEFAULT_JOB, file_name(f"{name}.job"))

    # Settings

    def _read_xml(self, name: str) -> ET.Element | None:
        try:
            return config.parse(self.read_file(name))
        except ScannerError as e:
            log.debug("cannot read %s: %s", name, e)
            return None

    def get_settings(self) -> Settings:
        cfg = config.parse(self.read_file(LIVE_CONFIG))
        return config.read_settings(cfg, self._read_xml(LIVE_TRANSFORM))

    def apply_settings(self, settings: Settings) -> None:
        """Change the live job (lost on reboot unless saved with save_job) and check the result."""
        if split := settings.split_frame_rate():
            for part in split:
                self.apply_settings(part)
            return
        self.ensure_stopped()
        cfg = config.parse(self.read_file(LIVE_CONFIG))
        tfm = self._read_xml(LIVE_TRANSFORM)
        cfg_changed, tfm_changed = config.apply_settings(cfg, tfm, settings)
        if cfg_changed:
            self.write_file(LIVE_CONFIG, config.serialize(cfg))
        if tfm_changed and tfm is not None:
            self.write_file(LIVE_TRANSFORM, config.serialize(tfm))
        # The sensor may adjust values (e.g. a frame rate above what the exposure allows).
        for difference in settings.differences(self.get_settings()):
            log.warning("sensor adjusted %s", difference)

    def _read_message(self, deadline: float) -> tuple[int, bool, bytes]:
        """The next data message; TimeoutError at the deadline, keeping what was received so far."""
        assert self._data
        while True:
            if len(self._rx) >= 6:
                size, control = struct.unpack_from("<IH", self._rx)
                if size < 6:
                    raise ScannerError(f"invalid data message size {size}")
                if len(self._rx) >= size:
                    message = bytes(self._rx[:size])
                    del self._rx[:size]
                    if self.raw_log:
                        self.raw_log.write(message)
                    return control & 0x7FFF, bool(control & LAST_MESSAGE_FLAG), message[6:]
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError
            self._data.settimeout(remaining)
            chunk = self._data.recv(1 << 20)
            if not chunk:
                raise ScannerError("sensor closed the connection")
            self._rx += chunk

    def _next_group(self, timeout: float, wanted: tuple[int, ...], what: str) -> dict[int, bytes]:
        """The next message group containing one of the `wanted` message types; others are skipped.

        Raises ScanTimeout when none arrives within `timeout`; what was received so far is kept,
        so receiving can continue with the next call.
        """
        if not self._data:
            raise ScannerError("not connected")
        deadline = time.monotonic() + timeout
        seen: Counter[int] = Counter()
        while True:
            try:
                msg_type, last, body = self._read_message(deadline)
            except TimeoutError:
                hint = f"message types received: {dict(seen)}" if seen else "no data received"
                raise ScanTimeout(
                    f"no {what} within {timeout:g} s ({hint}). Check the sensor's scan mode and "
                    f"that the Gocator Ethernet output includes the {what}."
                ) from None
            seen[msg_type] += 1
            self._group.setdefault(msg_type, body)
            if last:
                group, self._group = self._group, {}
                if any(t in group for t in wanted):
                    return group

    def grab(self, timeout: float) -> Scan:
        """Wait for the next message group that contains a Uniform Surface (others are skipped)."""
        return scan_from_group(self._next_group(timeout, (MSG_UNIFORM_SURFACE,), "surface"))

    def grab_profiles(self, timeout: float) -> ProfileBatch:
        """Wait for the next message group with profiles (uniform or point cloud)."""
        return profiles_from_group(self._next_group(timeout, (MSG_UNIFORM_PROFILE, MSG_PROFILE_POINT_CLOUD), "profiles"))

"""Settings <-> classic firmware configuration XML (_live.cfg) and transform XML (_live.tfm).

Paths and values: Gocator Line Profile Sensors user manual, "Gocator Device Files". In the XML the
element text is the setting; the attributes are read-only constraints the sensor computed
for the current configuration: min/max for numbers, options (CSV) for choices, and
used="0" for settings that don't apply right now.
"""

import xml.etree.ElementTree as ET

from ...scanner import CHOICES, ScannerError, Settings, check_range, choice_index, choice_name, format_number

DEVICE = "Setup/Devices/Device[@index='0']"  # the main sensor
ENUMS = {  # Settings field (a CHOICES key): path
    "scan_mode": "Setup/ScanMode",
    "trigger_source": "Setup/Trigger/Source",
    "surface_generation": "Setup/SurfaceGeneration/Type",
    "surface_start": "Setup/SurfaceGeneration/FixedLength/StartTrigger",
    "x_spacing_type": f"{DEVICE}/SpacingIntervalType",
}
NUMBERS = {
    "frame_rate": "Setup/Trigger/FrameRate",
    "exposure": f"{DEVICE}/Exposure",
    "surface_length": "Setup/SurfaceGeneration/FixedLength/Length",
}
MAX_FRAME_RATE = "Setup/Trigger/MaxFrameRateEnabled"
FLAGS = {"uniform_spacing": "Setup/UniformSpacingEnabled"}
ORIENTATION = "Setup/Layout/Orientation"  # read only (the value attribute: in use)  # Settings field: path of a 0/1 setting
SPACING = f"{DEVICE}/SpacingInterval"  # text: the custom spacing; value attribute: the spacing in use
# Per axis: the divisor (value attribute: in use) and whether the sensor's default is used instead.
SUBSAMPLING = {axis: (f"{DEVICE}/{axis.upper()}Subsampling", f"{DEVICE}/{axis.upper()}SubsamplingDefaultEnabled") for axis in "xz"}
AREA = [f"{DEVICE}/ActiveArea/{name}" for name in ("X", "Z", "Width", "Height")]
SPEED = "Speed"  # in the transform XML
# Ethernet outputs (Gocator protocol) needed to receive data in each scan mode.
OUTPUTS = {"surface": ("Surfaces", "SurfaceIntensities"), "profile": ("Profiles", "ProfileIntensities")}


def parse(data: bytes) -> ET.Element:
    try:
        return ET.fromstring(data)
    except ET.ParseError as e:
        raise ScannerError(f"invalid XML from sensor: {e}") from e


def serialize(root: ET.Element) -> bytes:
    return b'<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding="unicode").encode()


def _element(root: ET.Element, path: str) -> ET.Element:
    el = root.find(path)
    if el is None:
        raise ScannerError(f"{path} not found in the sensor configuration")
    return el


def _number(el: ET.Element) -> float:
    return float((el.text or "0").strip())


def _options(el: ET.Element) -> list[int] | None:
    text = el.get("options")
    return [int(o) for o in text.split(",") if o] if text else None


def _set(root: ET.Element, path: str, value: float, label: str) -> None:
    """Set a numeric setting after checking it against the sensor's constraints."""
    el = _element(root, path)
    lo, hi = el.get("min"), el.get("max")
    check_range(label, value, None if lo is None else float(lo), None if hi is None else float(hi))
    el.text = format_number(value)


def _set_enum(root: ET.Element, field: str, name: str) -> None:
    el = _element(root, ENUMS[field])
    el.text = str(choice_index(field, name, _options(el)))


def read_settings(cfg: ET.Element, tfm: ET.Element | None) -> Settings:
    s = Settings()
    for field, path in ENUMS.items():
        el = cfg.find(path)
        if el is not None:
            setattr(s, field, choice_name(field, int(_number(el))))
    for field, path in NUMBERS.items():
        el = cfg.find(path)
        if el is not None:
            setattr(s, field, _number(el))
    el = cfg.find(MAX_FRAME_RATE)
    if el is not None:
        s.max_frame_rate = _number(el) == 1
    for field, path in FLAGS.items():
        if (el := cfg.find(path)) is not None:
            setattr(s, field, _number(el) == 1)
    el = cfg.find(NUMBERS["frame_rate"])
    if el is not None and (limit := el.get("max")) is not None:
        s.frame_rate_max = float(limit)
    if el is not None and (source := el.get("maxSource")) is not None:
        s.frame_rate_limit = choice_name("frame_rate_limit", int(source))
    if (el := cfg.find(ORIENTATION)) is not None:
        s.orientation = choice_name("orientation", int(float(el.get("value", el.text or 0))))
    for axis, (path, default_path) in SUBSAMPLING.items():
        if (el := cfg.find(path)) is not None:
            setattr(s, f"{axis}_subsampling", int(float(el.get("value", el.text or 1))))
        if (el := cfg.find(default_path)) is not None and el.get("used") != "0":
            setattr(s, f"{axis}_subsampling_default", _number(el) == 1)
    el = cfg.find(SPACING)
    if el is not None:
        s.x_spacing = float(el.get("value", el.text or 0)) or None
    area = [cfg.find(path) for path in AREA]
    if all(el is not None for el in area):
        x, z, width, height = (_number(el) for el in area if el is not None)
        s.active_area = (x, z, width, height)
    if tfm is not None and (el := tfm.find(SPEED)) is not None:
        s.travel_speed = _number(el)
    return s


def apply_settings(cfg: ET.Element, tfm: ET.Element | None, s: Settings) -> tuple[bool, bool]:
    """Write the non-None settings into the XML trees. Returns (cfg changed, tfm changed)."""
    cfg_changed = False
    for field in ENUMS:
        if (name := getattr(s, field)) is not None:
            _set_enum(cfg, field, name)
            cfg_changed = True

    for axis, (path, default_path) in SUBSAMPLING.items():
        default = cfg.find(default_path)
        has_default = default is not None and default.get("used") != "0"
        if getattr(s, f"{axis}_subsampling_default"):
            if not has_default:
                raise ScannerError(f"{axis}_subsampling: this sensor has no default subsampling")
            default.text = "1"
            cfg_changed = True
        if (divisor := s.explicit_subsampling(axis)) is not None:
            el = _element(cfg, path)
            if (options := _options(el)) is not None and divisor not in options:
                raise ScannerError(f"{axis}_subsampling: 1/{divisor} is not available (available: {', '.join(f'1/{o}' for o in options)})")
            el.text = str(divisor)
            if has_default:
                default.text = "0"  # an explicit value only counts with the default off
            cfg_changed = True

    if (spacing := s.custom_x_spacing()) is not None:
        _element(cfg, ENUMS["x_spacing_type"]).text = str(CHOICES["x_spacing_type"].index("custom"))
        _set(cfg, SPACING, spacing, "x_spacing")
        cfg_changed = True

    for field, path in FLAGS.items():
        if (flag := getattr(s, field)) is not None:
            _element(cfg, path).text = "1" if flag else "0"
            cfg_changed = True

    max_rate = s.max_frame_rate_to_apply()
    if max_rate is not None:
        _element(cfg, MAX_FRAME_RATE).text = "1" if max_rate else "0"
        cfg_changed = True
    for field, path in NUMBERS.items():
        if (value := getattr(s, field)) is not None:
            if field == "frame_rate" and max_rate:
                continue
            _set(cfg, path, value, field)
            cfg_changed = True

    if s.active_area == "max":
        x, z, width, height = (_element(cfg, path) for path in AREA)
        values = [float(x.get("min", x.text or 0)), float(z.get("min", z.text or 0)),
                  float(width.get("max", width.text or 0)), float(height.get("max", height.text or 0))]
    elif isinstance(s.active_area, tuple):
        values = list(s.active_area)
    else:
        values = None
    if values is not None:
        for path, value in zip(AREA, values):
            _set(cfg, path, value, "active area " + path.rsplit("/", 1)[1])
        cfg_changed = True

    tfm_changed = False
    if s.travel_speed is not None:
        if tfm is None:
            raise ScannerError("the sensor has no transform file to store the travel speed in")
        _set(tfm, SPEED, s.travel_speed, "travel_speed")
        tfm_changed = True
    return cfg_changed, tfm_changed


def enable_outputs(cfg: ET.Element) -> list[str]:
    """Select the Ethernet outputs the current scan mode needs. Returns what was enabled."""
    mode = read_settings(cfg, None).scan_mode
    ethernet = cfg.find("Output/Ethernet")
    enabled = []
    for tag in OUTPUTS.get(mode or "", ()):
        el = ethernet.find(tag) if ethernet is not None else None
        options = _options(el) if el is not None else None
        if el is not None and options and not (el.text or "").strip():
            el.text = str(options[0])  # source 0 = the main sensor
            enabled.append(tag)
    return enabled

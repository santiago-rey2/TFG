"""The record saved with each scan: what the sensor was set to, and what it reported.

<name>_config.xml and <name>_transform.xml are the sensor's live configuration and transform
(_live.cfg, _live.tfm) as they were when the scan started: every setting, including the ones
the tool doesn't handle and the travel speed, which job files don't contain. Writing them
back with `gocator file put` restores that setup. <name>_settings.json summarizes it: the
arguments (in the --config format, so it can be passed back with -j), the job, the sensor,
the settings the tool knows, a hash of all setting values, and what the sensor reported.
"""

import hashlib
import json
import logging
import xml.etree.ElementTree as ET
from collections import Counter
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from .scanner import Scanner, ScannerError, ScanReport, Settings

log = logging.getLogger(__name__)

LIVE_CONFIG = "_live.cfg"
LIVE_TRANSFORM = "_live.tfm"


@dataclass
class Snapshot:
    """The sensor's state when a scan starts. None = could not be read."""

    time: str
    config: bytes | None
    transform: bytes | None
    job: tuple[str, bool] | None  # name, has unsaved changes
    sensor: dict[str, str | int] | None
    settings: Settings | None


def take_snapshot(scanner: Scanner) -> Snapshot:
    def read(what: str, get):
        try:
            return get()
        except (ScannerError, OSError) as e:
            log.warning("could not read the %s for the scan record: %s", what, e)
            return None

    return Snapshot(
        time=datetime.now().astimezone().isoformat(timespec="seconds"),
        config=read("configuration", lambda: scanner.read_file(LIVE_CONFIG)),
        transform=read("transform", lambda: scanner.read_file(LIVE_TRANSFORM)),
        job=read("loaded job", scanner.loaded_job),
        sensor=read("sensor identification", scanner.sensor_info),
        settings=read("settings", scanner.get_settings),
    )


def settings_hash(config: bytes) -> str:
    """Hash of every setting value in a configuration XML (element text by path).

    Attributes are left out: they are constraints the sensor computes (min, max, options),
    so equal settings give equal hashes, whatever sensor or moment they were read on.
    """
    lines = []

    def walk(el: ET.Element, path: str) -> None:
        seen: Counter[str] = Counter()
        for child in el:
            index = seen[child.tag]
            seen[child.tag] += 1
            child_path = f"{path}/{child.tag}[{index}]"
            if len(child):
                walk(child, child_path)
            elif (text := (child.text or "").strip()):
                lines.append(f"{child_path}={text}")

    walk(ET.fromstring(config), "")
    return "sha256:" + hashlib.sha256("\n".join(lines).encode()).hexdigest()


def _settings_dict(s: Settings) -> dict[str, Any]:
    return {k: list(v) if isinstance(v, tuple) else v for k, v in asdict(s).items() if v is not None}


def write_record(out_dir: Path, name: str, snapshot: Snapshot, record: dict[str, Any]) -> list[Path]:
    """Write <name>_settings.json (`record` plus the snapshot) and the configuration files."""
    out_dir.mkdir(parents=True, exist_ok=True)
    written = []
    files = {}
    for kind, data in (("config", snapshot.config), ("transform", snapshot.transform)):
        if data is not None:
            path = out_dir / f"{name}_{kind}.xml"
            path.write_bytes(data)
            files[kind] = path.name
            written.append(path)
    # What the scan ran with first, then what happened (`record`'s other entries).
    summary: dict[str, Any] = {"time": snapshot.time}
    summary.update({k: record[k] for k in ("command", "backend") if k in record})
    if snapshot.sensor is not None:
        summary["sensor"] = snapshot.sensor
    if snapshot.job is not None:
        summary["job"] = {"name": snapshot.job[0], "unsaved_changes": snapshot.job[1]}
    if "arguments" in record:
        summary["arguments"] = record["arguments"]
    if snapshot.settings is not None:
        summary["settings"] = _settings_dict(snapshot.settings)
    if snapshot.config is not None:
        try:
            summary["settings_hash"] = settings_hash(snapshot.config)
        except ET.ParseError as e:
            log.warning("could not hash the configuration: %s", e)
    summary["files"] = files
    summary.update({k: v for k, v in record.items() if k not in summary})
    path = out_dir / f"{name}_settings.json"
    path.write_text(json.dumps(summary, indent=2, default=str) + "\n")
    written.append(path)
    return written


def report_dict(report: ScanReport) -> dict[str, Any]:
    return {k: v for k, v in asdict(report).items() if v is not None and v != [] and v != {}}

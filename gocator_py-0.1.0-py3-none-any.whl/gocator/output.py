"""Writers for scans. write_cend matches the files produced by CEND; write_ply writes point clouds."""

import json
from pathlib import Path

import numpy as np
from PIL import Image

from .scanner import Grid, PointCloud, Scan


def _write_metadata(grid: Grid, path: Path) -> None:
    length, width = grid.data.shape
    meta = {
        "xResolution": grid.x_resolution,
        "yResolution": grid.y_resolution,
        "zResolution": grid.z_resolution or 0,
        "xOffset": grid.x_offset,
        "yOffset": grid.y_offset,
        "zOffset": grid.z_offset or 0,
        "Width": width,
        "Length": length,
    }
    path.write_text(json.dumps(meta, indent=2))


def write_cend(scan: Scan, out_dir: Path, name: str) -> list[Path]:
    """Write <name>_UniformSurface_XYZ.png (16-bit, raw height + 32768; 0 = no data),
    <name>_SurfaceIntensity_XYI.png (8-bit) and a *_metadata.json (mm) for each."""
    out_dir.mkdir(parents=True, exist_ok=True)
    written = []

    base = out_dir / f"{name}_UniformSurface"
    heights = (scan.heights.data.astype(np.int32) + 32768).astype(np.uint16)
    Image.fromarray(heights).save(f"{base}_XYZ.png")
    _write_metadata(scan.heights, Path(f"{base}_metadata.json"))
    written += [Path(f"{base}_XYZ.png"), Path(f"{base}_metadata.json")]

    if scan.intensity is not None:
        base = out_dir / f"{name}_SurfaceIntensity"
        Image.fromarray(scan.intensity.data).save(f"{base}_XYI.png")
        _write_metadata(scan.intensity, Path(f"{base}_metadata.json"))
        written += [Path(f"{base}_XYI.png"), Path(f"{base}_metadata.json")]

    return written


def write_ply(cloud: PointCloud, out_dir: Path, name: str, y_resolution: float, y_negated: bool = False) -> list[Path]:
    """Write <name>_PointCloud.ply: binary little-endian PLY, x/y/z as float32 mm (+ uchar intensity).

    x and z are the sensor's values; y is the row (frame - first frame) times the y spacing,
    negative when y_negated (the Reverse layout; see ProfileCloud.cloud).
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    fields = [("x", "<f4"), ("y", "<f4"), ("z", "<f4")] + ([("intensity", "u1")] if cloud.intensity is not None else [])
    vertices = np.empty(len(cloud.x), dtype=fields)
    vertices["x"], vertices["y"], vertices["z"] = cloud.x, cloud.y, cloud.z
    if cloud.intensity is not None:
        vertices["intensity"] = cloud.intensity
    header = [
        "ply", "format binary_little_endian 1.0",
        "comment gocator-py point cloud; units: mm",
        f"comment y = {'-' if y_negated else ''}row * {y_resolution:.9g} mm (row = frame index - first frame index)",
    ] + ([
        "comment y negated: the sensor's layout is Reverse (mirrored handedness), so that 3D views show the scan as it is",
    ] if y_negated else []) + [
        f"element vertex {len(vertices)}",
        "property float x", "property float y", "property float z",
    ] + (["property uchar intensity"] if cloud.intensity is not None else []) + ["end_header"]
    path = out_dir / f"{name}_PointCloud.ply"
    with open(path, "wb") as f:
        f.write(("\n".join(header) + "\n").encode("ascii"))
        f.write(vertices.tobytes())
    return [path]

"""gocator: scan with and configure a Gocator sensor (classic firmware).

  gocator scan                     start, receive one surface, stop, save the images
  gocator scan --distance MM       scan that far: profile mode stops there; surface mode joins surfaces
  gocator settings [--exposure..]  show the main settings, or change them first
  gocator job list|current|load|save|default
  gocator file list|get|put        raw access to sensor files (e.g. _live.cfg, backups)

Settings changes go to the live job: they are lost when the sensor reboots or loads
another job, unless saved with `gocator job save NAME`. Settings given to scan are for that
scan only.

scan and settings take -j/--config FILE: a JSON object of the same options, e.g.
{"speed": 12, "x-spacing": 0.06, "distance": 800, "wait": true}. Options on the command line
override it. Each scan's <name>_settings.json can be passed back the same way.

Backends (--backend or GOCATOR_BACKEND): protocol (default, pure Python) or gosdk (LMI's
GoSdk; needs GOCATOR_GOSDK set to the directory with its libraries).
"""

import argparse
import contextlib
import json
import logging
import math
import os
import shlex
import sys
import threading
import time
from pathlib import Path

from . import session
from .archive import Snapshot, report_dict, take_snapshot, write_record
from .backends.gosdk import HEALTH_PORT
from .backends.protocol import CONTROL_PORT, DATA_PORT
from .output import write_cend
from .scanner import (
    CHOICES,
    PIECE_SETTINGS,
    PiecePlan,
    Scan,
    Scanner,
    ScannerError,
    ScanReport,
    Settings,
    check_pieces,
    join_pieces,
    plan_pieces,
    scan_once,
    scan_pieces,
    temporary_settings,
)
from .session import ProfileScan, apply_auto_frame_rate, scan_folder

log = logging.getLogger("gocator")


def _choices(field: str) -> list[str]:
    return list(CHOICES[field])


def add_settings_arguments(parser: argparse.ArgumentParser, title: str) -> None:
    group = parser.add_argument_group(title)
    group.add_argument("--mode", choices=_choices("scan_mode"), help="scan mode")
    group.add_argument("--trigger-source", choices=_choices("trigger_source"))
    group.add_argument(
        "--frame-rate", metavar="HZ|max|auto",
        help="frame rate for time triggering: Hz, 'max', or 'auto' (travel speed / x spacing: y spacing = x spacing)",
    )
    group.add_argument("--exposure", type=float, metavar="US", help="exposure in microseconds")
    group.add_argument(
        "--uniform-spacing", action=argparse.BooleanOptionalAction,
        help="resample profiles to the x spacing on the sensor (--no-uniform-spacing: the sensor's points, "
        "saved as a point cloud; profile scans only)",
    )
    group.add_argument("--surface", choices=_choices("surface_generation"), help="surface generation type")
    group.add_argument("--length", type=float, metavar="MM", help="fixed surface length")
    group.add_argument("--start", choices=_choices("surface_start"), help="what starts a fixed-length surface")
    group.add_argument("--speed", type=float, metavar="MM_S", help="travel speed (scales y with time triggering)")
    group.add_argument(
        "--x-subsampling", choices=["1", "2", "4", "default"],
        help="use every Nth camera column: fewer points per profile, less sensor CPU (default: the sensor's own)",
    )
    group.add_argument(
        "--z-subsampling", choices=["1", "2", "default"],
        help="use every Nth camera row: coarser heights, faster camera (default: the sensor's own; 1/2 on a 2640)",
    )
    group.add_argument(
        "--x-spacing", metavar="MM|max-res|balanced|max-speed",
        help="x spacing of the uniform data: a custom value in mm, or one of the sensor's presets",
    )
    group.add_argument(
        "--active-area", nargs="+", metavar="V", help="'max' (full range) or X Z WIDTH HEIGHT in mm"
    )


def settings_from_args(args: argparse.Namespace, parser: argparse.ArgumentParser) -> Settings | None:
    s = Settings(
        scan_mode=args.mode,
        trigger_source=args.trigger_source,
        exposure=args.exposure,
        uniform_spacing=args.uniform_spacing,
        surface_generation=args.surface,
        surface_length=args.length,
        surface_start=args.start,
        travel_speed=args.speed,
    )
    args.auto_frame_rate = args.frame_rate == "auto"  # resolved once the other settings are in place
    if args.frame_rate == "max":
        s.max_frame_rate = True
    elif args.frame_rate is not None and not args.auto_frame_rate:
        try:
            s.frame_rate = float(args.frame_rate)
        except ValueError:
            parser.error(f"--frame-rate: expected a number, 'max' or 'auto', got {args.frame_rate!r}")
    for axis in "xz":
        if (value := getattr(args, f"{axis}_subsampling")) == "default":
            setattr(s, f"{axis}_subsampling_default", True)
        elif value is not None:
            setattr(s, f"{axis}_subsampling", int(value))
    if args.x_spacing in CHOICES["x_spacing_type"][:3]:
        s.x_spacing_type = args.x_spacing
    elif args.x_spacing is not None:
        try:
            s.x_spacing = float(args.x_spacing)
        except ValueError:
            parser.error(f"--x-spacing: expected a number or max-res, balanced, max-speed; got {args.x_spacing!r}")
    if args.active_area == ["max"]:
        s.active_area = "max"
    elif args.active_area is not None:
        try:
            x, z, width, height = (float(v) for v in args.active_area)
        except ValueError:
            parser.error("--active-area: expected 'max' or four numbers: X Z WIDTH HEIGHT")
        s.active_area = (x, z, width, height)
    return None if s == Settings() else s


def settings_rows(s: Settings) -> list[tuple[str, str]]:
    rate = "?" if s.frame_rate is None else f"{s.frame_rate:g} Hz" + (" (max)" if s.max_frame_rate else "")
    area = "?" if not isinstance(s.active_area, tuple) else "x {:g}, z {:g}, width {:g}, height {:g} mm".format(*s.active_area)

    def unit(value, suffix):
        return "?" if value is None else f"{value:g} {suffix}"

    rate_max = unit(s.frame_rate_max, "Hz") + (f" (limited by {s.frame_rate_limit})" if s.frame_rate_limit else "")
    # Row spacing of a time-triggered scan: the distance travelled between frames.
    y_spacing = "?"
    if s.trigger_source == "time" and s.travel_speed and s.frame_rate:
        y_spacing = f"{s.travel_speed / s.frame_rate:.4g} mm"
    return [
        ("scan mode", s.scan_mode or "?"),
        ("trigger source", s.trigger_source or "?"),
        ("frame rate", rate),
        ("max frame rate", rate_max),
        ("exposure", unit(s.exposure, "us")),
        ("uniform spacing", "?" if s.uniform_spacing is None else "on" if s.uniform_spacing else "off (point clouds)"),
        ("surface generation", s.surface_generation or "?"),
        ("surface length", unit(s.surface_length, "mm")),
        ("surface start", s.surface_start or "?"),
        ("travel speed", unit(s.travel_speed, "mm/s")),
        ("x spacing", unit(s.x_spacing, "mm") + (f" ({s.x_spacing_type})" if s.x_spacing_type else "")),
        ("x subsampling", subsampling(s.x_subsampling, s.x_subsampling_default)),
        ("z subsampling", subsampling(s.z_subsampling, s.z_subsampling_default)),
        ("y spacing", y_spacing),
        ("active area", area),
        ("layout", s.orientation or "?"),
    ]


def subsampling(divisor: int | None, default: bool | None) -> str:
    if divisor is None:
        return "?"
    return ("1 (all)" if divisor == 1 else f"1/{divisor}") + (" (sensor default)" if default else "")


def print_settings(s: Settings) -> None:
    for name, value in settings_rows(s):
        print(f"{name:20}{value}")


def log_settings(scanner: Scanner) -> None:
    try:
        current = scanner.get_settings()
    except ScannerError as e:
        log.warning("could not read the settings: %s", e)
        return
    for name, value in settings_rows(current):
        log.debug("%-20s%s", name, value)


def save(scan: Scan, out_dir: Path, name: str) -> None:
    for path in write_cend(scan, out_dir, name):
        log.info("wrote %s", path)


def cmd_scan(scanner: Scanner, args: argparse.Namespace, settings: Settings | None) -> None:
    if args.job:
        scanner.load_job(args.job)
        log.info("loaded job %s", args.job)
    # Each scan gets a folder: its images, pieces/ (with --output pieces|both) and settings/ (the record).
    args.folder = scan_folder(args.out, args.name)
    name = args.folder.name
    snapshot: list[Snapshot] = []
    report = ScanReport()

    def before_surface() -> None:
        if args.wait:
            input("press Enter to start the surface... ")
        for n in range(math.ceil(args.delay), 0, -1):
            print(f"{n}...", flush=True)
            time.sleep(min(1.0, args.delay - (n - 1)))
        log.info("scan started; move the sensor now (waiting up to %g s)", args.timeout)

    def record(details: dict) -> None:
        """Save the scan's record (settings it ran with, what the sensor reported)."""
        if not snapshot:
            return
        data = {"command": args.command_line, "backend": args.backend, "arguments": args.arguments, **details}
        data["report"] = report_dict(report)
        for path in write_record(args.folder / "settings", name, snapshot[0], data):
            log.info("wrote %s", path)

    # Profile scans when the scan mode (given, or the job's) is profile; surface scans otherwise.
    explicit = settings or Settings()
    profiles = (explicit.scan_mode or scanner.get_settings().scan_mode) == "profile"
    if profiles:
        for flag, value in (("--piece", args.piece), ("--max-piece", args.max_piece), ("--output", args.output)):
            if value is not None:
                raise ScannerError(f"{flag} is for surface scans in pieces; this is a profile scan")
    elif explicit.uniform_spacing is False:
        raise ScannerError("--no-uniform-spacing is for profile scans (surface scans need uniform spacing)")
    if profiles:
        info = {"command": args.command_line, "backend": args.backend, "arguments": args.arguments}
        run_profile_scan(scanner, args, explicit, before_surface, info)
        return

    # Settings given to scan are for this scan only: restored once the sensor stops.
    temporary = settings is not None or args.distance is not None or args.auto_frame_rate
    with temporary_settings(scanner) if temporary else contextlib.nullcontext(lambda: None) as started:

        def ready() -> None:
            """The scan's settings are in place: from here on, they are what the scan runs with."""
            started()
            scanner.enable_outputs()  # Start would do it; first, so the snapshot includes it
            snapshot[:] = [take_snapshot(scanner)]

        if args.distance is not None:
            plan, pieces = scan_in_pieces(scanner, args, settings, name, before_surface, ready, report, record)
        else:
            scan = scan_one(scanner, args, settings, before_surface, ready, report)
    if args.distance is not None:
        problems = save_pieces(args, name, plan, pieces)
        record({"pieces": piece_details(plan, pieces, problems)})
    else:
        save(scan, args.folder, name)
        length, width = scan.heights.data.shape
        record({"scan": {"width": width, "length": length, "frame_index": scan.frame_index, "timestamp_us": scan.timestamp_us}})


def run_profile_scan(scanner: Scanner, args: argparse.Namespace, explicit: Settings, before_surface, info: dict) -> None:
    """Profile mode: a ProfileScan (see session.py) until --distance is covered or Enter is pressed."""

    def before_start() -> None:
        if log.isEnabledFor(logging.DEBUG):
            log_settings(scanner)
        before_surface()

    scan = ProfileScan(
        scanner, explicit, frame_rate="auto" if args.auto_frame_rate else None, distance=args.distance,
        timeout=args.timeout, before_start=before_start,
    )
    scan.start()
    try:
        enter = threading.Event()
        if args.distance is None:
            log.info("press Enter to stop")
            threading.Thread(target=wait_for_enter, args=(enter,), daemon=True).start()
        while not enter.is_set() and not scan.wait(0.2):  # (short waits: Ctrl+C stays responsive)
            pass
        result = scan.stop()
    except BaseException as e:
        # The scan failed, or Ctrl+C: stop it if it still runs, and save what arrived.
        if scan.result is None:
            with contextlib.suppress(Exception):
                scan.stop()
        if (partial := scan.result) is not None and partial.frames.received:
            partial.error = partial.error or str(e) or type(e).__name__
            log.warning("scan failed after %d profiles; saving them", partial.frames.received)
            args.folder = partial.save(args.out, args.folder.name, info)
        raise
    args.folder = result.save(args.out, args.folder.name, info)


def wait_for_enter(stop: threading.Event) -> None:
    try:
        input()
    except (EOFError, OSError):  # no terminal: only --distance, a timeout or Ctrl+C end the scan
        return
    stop.set()


def scan_one(
    scanner: Scanner, args: argparse.Namespace, settings: Settings | None, before_surface, ready, report: ScanReport
) -> Scan:
    if settings:
        scanner.apply_settings(settings)
    if args.auto_frame_rate:
        apply_auto_frame_rate(scanner)
    ready()
    trigger = args.trigger == "yes"
    if args.trigger == "auto":
        try:
            trigger = scanner.get_settings().needs_software_trigger()
        except ScannerError as e:
            log.warning("could not read the settings (%s); not sending a software trigger", e)
    if log.isEnabledFor(logging.DEBUG):
        log_settings(scanner)

    def before() -> None:
        if trigger:
            log.info("sensor running (laser on)")
        before_surface()

    scan = scan_once(scanner, args.timeout, trigger=trigger, before_surface=before, report=report)
    length, width = scan.heights.data.shape
    log.info("received surface %d x %d (frame %s); sensor stopped", width, length, scan.frame_index)
    return scan


def piece_name(name: str, i: int, count: int) -> str:
    return f"{name}_p{i + 1:0{max(2, len(str(count)))}d}"


def piece_details(plan: PiecePlan, pieces: list[Scan], problems: list[str], error: str | None = None) -> dict:
    details = {
        "distance_mm": plan.distance, "count": plan.count, "length_mm": plan.length, "frame_rate": plan.frame_rate,
        "received": len(pieces), "frame_indexes": [p.frame_index for p in pieces], "problems": problems,
    }
    if error:
        details["error"] = error
    return details


def scan_in_pieces(
    scanner: Scanner, args: argparse.Namespace, settings: Settings | None, name: str, before_surface, ready,
    report: ScanReport, record,
) -> tuple[PiecePlan, list[Scan]]:
    """--distance in surface mode: plan the pieces and scan them. Pieces received before a failure are saved.

    The planner aims for --frame-rate, or by default square pixels (travel speed / x spacing).
    """
    explicit = settings or Settings()
    if explicit.surface_length is not None:
        log.warning("--length is ignored: --distance sets the surface length of the pieces")
    if explicit.max_frame_rate:
        raise ScannerError("surface scans in pieces need a frame rate to aim for: a number or 'auto', not 'max'")
    upfront = Settings(**{f: v for f, v in vars(explicit).items() if f not in ("surface_length", "frame_rate", "max_frame_rate")})
    if upfront != Settings():
        scanner.apply_settings(upfront)
    plan = plan_pieces(scanner, args.distance, explicit.frame_rate, args.piece, args.max_piece)
    ready()
    if log.isEnabledFor(logging.DEBUG):
        log_settings(scanner)
    received: list[Scan] = []
    try:
        scan_pieces(scanner, plan.count, args.timeout, before_surface=before_surface, received=received, report=report)
    except BaseException as e:
        if received:
            log.warning("scan failed after %d of %d pieces; saving them", len(received), plan.count)
            for i, piece in enumerate(received):
                save(piece, args.folder / "pieces", piece_name(name, i, plan.count))
            record({"pieces": piece_details(plan, received, [], error=str(e) or type(e).__name__)})
        raise
    return plan, received


def save_pieces(args: argparse.Namespace, name: str, plan: PiecePlan, pieces: list[Scan]) -> list[str]:
    problems = check_pieces(pieces, plan.frame_rate)
    for problem in problems:
        log.warning("%s", problem)
    if args.output in ("pieces", "both"):
        for i, piece in enumerate(pieces):
            save(piece, args.folder / "pieces", piece_name(name, i, plan.count))
    if args.output in (None, "joined", "both"):
        scan = join_pieces(pieces, plan.distance)
        length, width = scan.heights.data.shape
        log.info("joined %d pieces into %d x %d", len(pieces), width, length)
        save(scan, args.folder, name)
    return problems


def cmd_settings(scanner: Scanner, args: argparse.Namespace, settings: Settings | None) -> None:
    if settings:
        scanner.apply_settings(settings)
    if args.auto_frame_rate:
        apply_auto_frame_rate(scanner)
    print_settings(scanner.get_settings())


def cmd_job(scanner: Scanner, args: argparse.Namespace, settings: Settings | None) -> None:
    if args.action == "list":
        for name in scanner.list_jobs():
            print(name)
    elif args.action == "current":
        name, changed = scanner.loaded_job()
        print(name + (" (unsaved changes)" if changed else ""))
    elif args.name is None:
        raise ScannerError(f"job {args.action} needs a job name")
    elif args.action == "load":
        scanner.load_job(args.name)
    elif args.action == "save":
        scanner.save_job(args.name)
    elif args.action == "default":
        scanner.set_default_job(args.name)


def cmd_file(scanner: Scanner, args: argparse.Namespace, settings: Settings | None) -> None:
    if args.action == "list":
        for name in scanner.list_files(args.args[0] if args.args else ""):
            print(name)
    elif args.action == "get" and len(args.args) == 2:
        data = scanner.read_file(args.args[0])
        Path(args.args[1]).write_bytes(data)
        log.info("saved %s (%d bytes) to %s", args.args[0], len(data), args.args[1])
    elif args.action == "put" and len(args.args) == 2:
        scanner.ensure_stopped()
        scanner.write_file(args.args[1], Path(args.args[0]).read_bytes())
        log.info("uploaded %s to %s", args.args[0], args.args[1])
    else:
        raise ScannerError("usage: gocator file list [EXT] | get NAME DEST | put SOURCE NAME")


def add_config_argument(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "-j", "--config", type=Path, metavar="FILE",
        help="JSON file with options of this command, by long name (e.g. {\"total\": 800, \"wait\": true}); "
        "command-line options override it. A scan's <name>_settings.json works too",
    )


# --config files mirror the command line: {"frame-rate": 400} is --frame-rate 400.
NOT_IN_CONFIG = {"config", "help"}
NOT_RECORDED = {"config", "help", "name", "save-raw"}  # reusing a record must not overwrite its files
RENAMED = {"total": "distance"}  # old option names still accepted (records keep them)


def option_key(action: argparse.Action) -> str:
    """An option's name in --config files: its first long option without the dashes."""
    long = [o for o in action.option_strings if o.startswith("--")]
    return (long[0] if long else action.option_strings[0]).lstrip("-")


def command_parser(parser: argparse.ArgumentParser, command: str) -> argparse.ArgumentParser:
    for action in parser._actions:
        if isinstance(action, argparse._SubParsersAction):
            return action.choices[command]
    raise KeyError(command)


def config_argv(path: Path, parser: argparse.ArgumentParser) -> list[str]:
    """The command-line arguments equivalent to a --config file."""
    try:
        data = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as e:
        parser.error(f"--config {path}: {e}")
    if isinstance(data, dict) and isinstance(data.get("arguments"), dict):
        data = data["arguments"]  # a scan's record
    if not isinstance(data, dict):
        parser.error(f"--config {path}: expected a JSON object of options")
    actions = {option_key(a): a for a in parser._actions if a.option_strings}
    argv = []
    for key, value in data.items():
        name = key.removeprefix("--")
        action = actions.get(name)
        if action is None or name in NOT_IN_CONFIG:
            parser.error(f"--config {path}: unknown option {key!r}")
        if action.nargs == 0 or isinstance(action, argparse.BooleanOptionalAction):  # a flag
            if not isinstance(value, bool):
                parser.error(f"--config {path}: {key!r} takes true or false")
            if value:
                argv.append(f"--{name}")
            elif isinstance(action, argparse.BooleanOptionalAction):
                argv.append(f"--no-{name}")
            continue
        values = value if isinstance(value, list) and action.nargs in ("+", "*") else [value]
        if not values or any(v is None or isinstance(v, bool | list | dict) for v in values):
            parser.error(f"--config {path}: invalid value for {key!r}: {json.dumps(value)}")
        argv += [f"--{name}", *(str(v) for v in values)]
    return argv


def _json_value(value):
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, list):
        return [_json_value(v) for v in value]
    if isinstance(value, str):
        try:
            number = float(value)
        except ValueError:
            return value
        return int(number) if number.is_integer() and "." not in value else number
    return value


def given_arguments(argv: list[str], parser: argparse.ArgumentParser, args: argparse.Namespace) -> dict:
    """The options given (in a --config file or on the command line), in the --config format."""
    given = {}
    for token in argv:
        action = parser._option_string_actions.get(token.split("=", 1)[0]) if token.startswith("-") else None
        if action is None or (key := option_key(action)) in NOT_RECORDED:
            continue
        given[RENAMED.get(key, key)] = _json_value(getattr(args, action.dest))
    return given


def build_parser() -> argparse.ArgumentParser:
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--host", default="192.168.1.10", help="sensor IP (default: %(default)s)")
    common.add_argument("--control-port", type=int, default=CONTROL_PORT)
    common.add_argument("--data-port", type=int, default=DATA_PORT)
    common.add_argument("--health-port", type=int, default=HEALTH_PORT, help="health channel (dropped data reports)")
    common.add_argument(
        "--backend",
        choices=["protocol", "gosdk"],
        default=os.environ.get("GOCATOR_BACKEND", "protocol"),
        help="protocol (pure Python) or gosdk (LMI's SDK) (default: %(default)s)",
    )
    common.add_argument("-v", "--verbose", action="store_true")

    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    commands = parser.add_subparsers(dest="command", required=True)

    scan = commands.add_parser("scan", parents=[common], help="scan one surface and save it", allow_abbrev=False)
    add_config_argument(scan)
    scan.add_argument("--job", help="load this saved job first (it stays loaded)")
    add_settings_arguments(
        scan, "sensor settings (for this scan only: applied to the live job after --job, restored when the "
        "sensor stops, except settings someone else changed meanwhile; use `gocator settings` to keep them)"
    )
    scan.add_argument("--out", type=Path, default=Path("scans"), help="where scan folders go (default: %(default)s)")
    scan.add_argument(
        "--name", help="the scan's folder (in --out) and file name prefix; must not exist yet (default: scan_<timestamp>)"
    )
    scan.add_argument("--timeout", type=float, default=120.0, help="seconds to wait for the surface (default: %(default)s)")
    scan.add_argument(
        "--trigger",
        choices=["auto", "yes", "no"],
        default="auto",
        help="send a software trigger after Start; auto = when the job's surface start trigger is 'software'",
    )
    scan.add_argument("--wait", action=argparse.BooleanOptionalAction, default=False, help="wait for Enter before the surface starts")
    scan.add_argument("--delay", type=float, default=0.0, metavar="S", help="countdown before the surface starts (after --wait)")
    pieces = scan.add_argument_group(
        "scan distance",
        "--distance sets how far the scan goes. In Profile mode the tool stops the sensor after that "
        "many profiles (distance / y spacing). In Surface mode, where the sensor lowers its maximum frame "
        "rate so a whole surface fits in its memory, it scans back-to-back fixed-length surfaces (pieces, "
        "time triggered, sequential start) and joins them; settings it changes are restored afterwards.",
    )
    pieces.add_argument(
        "--distance", type=float, metavar="MM",
        help="scan length along the travel. Surface mode: sets the surface length and aims for --frame-rate "
        "(default 'auto'); overrides --length. Profile mode: only decides when to stop",
    )
    pieces.add_argument("--total", type=float, dest="distance", help=argparse.SUPPRESS)  # its old name
    size = pieces.add_mutually_exclusive_group()
    size.add_argument("--max-piece", type=float, metavar="MM", help="surface mode: equal pieces of at most MM (no probing of the sensor)")
    size.add_argument("--piece", type=float, metavar="MM", help="surface mode: pieces of exactly MM; the last one overshoots and the joined scan is cropped")
    pieces.add_argument(
        "--output", choices=["joined", "pieces", "both"],
        help="surface mode: save the joined scan, each piece (pieces/<name>_p01...), or both (default: joined)",
    )
    scan.add_argument(
        "--save-raw", type=Path, help="also save the raw data-channel bytes (replayable with gocator-mock --replay; protocol backend only)"
    )
    scan.set_defaults(run=cmd_scan)

    settings = commands.add_parser("settings", parents=[common], help="show the main settings, or change them", allow_abbrev=False)
    add_config_argument(settings)
    add_settings_arguments(settings, "sensor settings (written to the live job; kept until a reboot or job load)")
    settings.set_defaults(run=cmd_settings)

    job = commands.add_parser("job", parents=[common], help="list, load, save jobs", allow_abbrev=False)
    job.add_argument("action", choices=["list", "current", "load", "save", "default"])
    job.add_argument("name", nargs="?")
    job.set_defaults(run=cmd_job)

    file = commands.add_parser("file", parents=[common], help="raw access to sensor files", allow_abbrev=False)
    file.add_argument("action", choices=["list", "get", "put"])
    file.add_argument("args", nargs="*", help="list: [EXT] | get: NAME DEST | put: SOURCE NAME")
    file.set_defaults(run=cmd_file)
    return parser


def check_piece_arguments(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.distance is None:
        for flag, value in (("--piece", args.piece), ("--max-piece", args.max_piece), ("--output", args.output)):
            if value is not None:
                parser.error(f"{flag} needs --distance")
        return
    for flag, value in (("--distance", args.distance), ("--piece", args.piece), ("--max-piece", args.max_piece)):
        if value is not None and value <= 0:
            parser.error(f"{flag} must be positive")
    if args.mode == "profile":  # --distance only decides when to stop; the surface options don't apply
        for flag, value in (("--piece", args.piece), ("--max-piece", args.max_piece), ("--output", args.output)):
            if value is not None:
                parser.error(f"{flag} is for surface scans in pieces, not --mode profile")
        if args.trigger_source not in (None, "time"):
            parser.error("--distance scans need --trigger-source time")
        return
    for dest, field in (("mode", "scan_mode"), ("trigger_source", "trigger_source"),
                        ("surface", "surface_generation"), ("start", "surface_start")):
        needed = getattr(PIECE_SETTINGS, field)
        if getattr(args, dest) not in (None, needed):
            parser.error(f"--distance scans with --{dest.replace('_', '-')} {needed}")
    if args.mode == "surface" and args.frame_rate == "max":
        parser.error("surface scans in pieces need a frame rate to aim for: give a number or 'auto', not 'max'")
    if args.trigger == "yes":
        parser.error("--distance starts the pieces on Start (sequential); --trigger yes does not apply")


def open_scanner(args: argparse.Namespace, raw_log) -> Scanner:
    return session.open_scanner(args.host, args.backend, args.control_port, args.data_port, args.health_port, raw_log)


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    argv = sys.argv[1:] if argv is None else list(argv)
    typed = list(argv)
    args = parser.parse_args(argv)
    command = command_parser(parser, args.command)
    if getattr(args, "config", None):
        # The file's options go first, so the command line overrides them.
        argv = [argv[0], *config_argv(args.config, command), *argv[1:]]
        args = parser.parse_args(argv)
    args.arguments = given_arguments(argv[1:], command, args)
    args.command_line = shlex.join(["gocator", *typed])
    if args.backend not in ("protocol", "gosdk"):
        parser.error(f"unknown backend {args.backend!r} (from GOCATOR_BACKEND?)")
    if getattr(args, "save_raw", None) and args.backend != "protocol":
        parser.error("--save-raw needs the protocol backend (GoSdk owns the data connection)")
    setup_logging(args.verbose)
    settings = settings_from_args(args, parser) if hasattr(args, "mode") else None
    if getattr(args, "command", None) == "scan":
        check_piece_arguments(args, parser)

    # A scan keeps its full log (as with -v, with times) and saves it in its folder.
    capture = LogCapture() if args.command == "scan" else None
    if capture:
        log.addHandler(capture)
        log.debug("%s", args.command_line)
    try:
        return run(args, settings)
    finally:
        if capture:
            log.removeHandler(capture)
            capture.save(getattr(args, "folder", None))


def run(args: argparse.Namespace, settings: Settings | None) -> int:
    try:
        with contextlib.ExitStack() as stack:
            raw_log = stack.enter_context(open(args.save_raw, "wb")) if getattr(args, "save_raw", None) else None
            scanner = open_scanner(args, raw_log)
            scanner.connect()
            stack.callback(scanner.close)
            log.debug("connected to %s with the %s backend", args.host, args.backend)
            args.run(scanner, args, settings)
    except (ScannerError, OSError) as e:
        log.error("error: %s", e)
        return 1
    except KeyboardInterrupt:
        log.error("cancelled")
        return 130
    return 0


def setup_logging(verbose: bool) -> None:
    """The tool's messages are always made (a scan's saved log has them all); the console
    shows debug ones only with -v, as it does for other libraries' messages."""
    root = logging.getLogger()
    console = next((h for h in root.handlers if getattr(h, "gocator_console", False)), None)
    if console is None and not root.handlers:  # (tests may have installed their own)
        console = logging.StreamHandler()
        console.setFormatter(logging.Formatter("%(message)s"))
        console.gocator_console = True  # type: ignore[attr-defined]
        root.addHandler(console)
    if console is not None:
        console.setLevel(logging.DEBUG if verbose else logging.INFO)
    root.setLevel(logging.DEBUG if verbose else logging.INFO)
    log.setLevel(logging.DEBUG)


class LogCapture(logging.Handler):
    """Keeps the tool's log lines, at every level and with times, to save with a scan."""

    def __init__(self):
        super().__init__(logging.DEBUG)
        self.setFormatter(logging.Formatter("%(asctime)s.%(msecs)03d %(levelname)-7s %(message)s", "%Y-%m-%d %H:%M:%S"))
        self.lines: list[str] = []

    def emit(self, record: logging.LogRecord) -> None:
        self.lines.append(self.format(record))

    def save(self, folder: Path | None) -> None:
        """Write settings/<name>.log in the scan's folder, if the scan saved anything there."""
        if folder is None or not folder.exists():
            return
        path = folder / "settings" / f"{folder.name}.log"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("\n".join(self.lines) + "\n")
        log.info("wrote %s", path)


if __name__ == "__main__":
    sys.exit(main())

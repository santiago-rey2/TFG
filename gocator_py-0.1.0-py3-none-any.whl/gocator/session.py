"""Using gocator-py as a library: profile scans that the calling program stops.

    import gocator
    from gocator import ProfileScan, Settings

    with gocator.connect("192.168.1.10") as sensor:
        with ProfileScan(sensor, Settings(travel_speed=12), frame_rate="auto") as scan:
            robot.move_linear(...)          # the caller decides when the scan ends
        scan.result.save("scans", "run_017")

A ProfileScan receives profiles in a background thread from start() until stop() (or until
`distance` is covered). Settings given to it are temporary, as with `gocator scan`: they are
restored when it stops. The CLI's `gocator scan --mode profile` runs on the same code.
"""

import contextlib
import logging
import threading
from collections.abc import Callable, Generator
from dataclasses import dataclass, field, replace
from datetime import datetime
from pathlib import Path
from typing import Any, Self

from .archive import Snapshot, report_dict, take_snapshot, write_record
from .backends.gosdk import HEALTH_PORT, GoSdkScanner
from .backends.protocol import CONTROL_PORT, DATA_PORT, ProtocolScanner
from .output import write_cend, write_ply
from .scanner import (
    LATENCY_LOSS,
    PointCloud,
    ProfileCloud,
    ProfileFrames,
    ProfileImage,
    Scan,
    Scanner,
    ScannerError,
    ScanReport,
    Settings,
    scan_profiles,
    temporary_settings,
)

log = logging.getLogger(__name__)

BACKENDS = ("protocol", "gosdk")


def open_scanner(
    host: str = "192.168.1.10",
    backend: str = "protocol",
    control_port: int = CONTROL_PORT,
    data_port: int = DATA_PORT,
    health_port: int = HEALTH_PORT,
    raw_log=None,
) -> Scanner:
    """A Scanner for the sensor, not connected yet. raw_log: a binary file that gets every
    data message (protocol backend only)."""
    if backend == "gosdk":
        if raw_log is not None:
            raise ScannerError("a raw data log needs the protocol backend (GoSdk owns the data connection)")
        return GoSdkScanner(host, control_port, data_port, health_port)
    if backend != "protocol":
        raise ScannerError(f"unknown backend {backend!r} (known: {', '.join(BACKENDS)})")
    return ProtocolScanner(host, control_port, data_port, raw_log, health_port)


@contextlib.contextmanager
def connect(host: str = "192.168.1.10", backend: str = "protocol", **kwargs) -> Generator[Scanner, None, None]:
    """Connect to the sensor for the block (see open_scanner for the arguments)."""
    scanner = open_scanner(host, backend, **kwargs)
    scanner.connect()
    try:
        yield scanner
    finally:
        scanner.close()


def check_rate(s: Settings, rate: float) -> None:
    """Reject a frame rate above the cap the sensor computed for the current settings."""
    if s.frame_rate_max is not None and rate > s.frame_rate_max + 1e-6:
        limit = f", limited by {s.frame_rate_limit}" if s.frame_rate_limit else ""
        raise ScannerError(f"the sensor allows at most {s.frame_rate_max:g} Hz{limit}; {rate:g} Hz was asked for")


def apply_auto_frame_rate(scanner: Scanner) -> None:
    """Frame rate "auto": travel speed / x spacing, so that y spacing = x spacing."""
    s = scanner.get_settings()
    if not s.travel_speed or not s.x_spacing:
        raise ScannerError("frame rate auto needs the travel speed and the x spacing")
    rate = s.travel_speed / s.x_spacing
    check_rate(s, rate)
    scanner.apply_settings(Settings(frame_rate=rate))


def scan_folder(out_dir: Path | str, name: str | None = None) -> Path:
    """A new scan folder in out_dir: `name` (which must not exist yet), or scan_<timestamp>."""
    out_dir = Path(out_dir)
    if name:
        if (out_dir / name).exists():
            raise ScannerError(f"{out_dir / name} already exists; choose another --name or --out")
        return out_dir / name
    base = name = datetime.now().strftime("scan_%Y%m%d_%H%M%S")
    n = 1
    while (out_dir / name).exists():  # two scans in the same second
        n += 1
        name = f"{base}_{n}"
    return out_dir / name


@dataclass
class ScanResult:
    """What a profile scan produced: an image (uniform spacing) or a point cloud (uniform
    spacing off), how the frames went (`details`) and what the sensor reported (`report`).

    `image` / `cloud` are built when first used, and can be large. save() writes the same
    files as `gocator scan`.
    """

    frames: ProfileFrames
    y_resolution: float  # mm per row: travel speed / frame rate
    frame_rate: float  # Hz, configured
    negate_y: bool  # point clouds: y = -row * y_resolution (the Reverse layout)
    report: ScanReport
    snapshot: Snapshot | None = None  # the sensor's settings when the scan started
    error: str | None = None  # why the scan ended early, if it did
    ended: str | None = None  # how it ended: "stop", "distance", "sensor stopped" or "error"
    _built: tuple[Scan | PointCloud, dict] | None = field(default=None, repr=False)

    def _build(self) -> tuple[Scan | PointCloud, dict]:
        if self._built is None:
            if isinstance(self.frames, ProfileCloud):
                data, details = self.frames.cloud(self.y_resolution, negate_y=self.negate_y)
            else:
                assert isinstance(self.frames, ProfileImage)
                data, details = self.frames.scan(self.y_resolution)
            details["frame_rate"] = self.frame_rate
            if (measured := self.frames.measured_rate()) is not None:
                details["measured_frame_rate"] = round(measured, 3)
            details["y_resolution"] = self.y_resolution
            self._built = (data, details)
        return self._built

    @property
    def image(self) -> Scan | None:
        data = self._build()[0]
        return data if isinstance(data, Scan) else None

    @property
    def cloud(self) -> PointCloud | None:
        data = self._build()[0]
        return data if isinstance(data, PointCloud) else None

    @property
    def details(self) -> dict:
        """Rows, frames received / missing / repeated, frame rates, profiles per message (and the error)."""
        details = dict(self._build()[1])
        if self.ended:
            details["ended"] = self.ended
        if (cut := self.discarded_at_stop) is not None:
            details["discarded_at_stop"] = cut
        if self.error:
            details["error"] = self.error
        return details

    @property
    def discarded_at_stop(self) -> dict | None:
        """The end of the scan the sensor discarded when it stopped, if it was behind: the frames
        it had taken but not processed yet (its processing latency at Stop)."""
        latency = self.report.latency_at_stop
        if latency is None or latency <= LATENCY_LOSS:
            return None
        frames = round(latency * self.frame_rate)
        return {"seconds": round(latency, 3), "frames": frames, "mm": round(frames * self.y_resolution, 3)}

    def warn(self) -> None:
        """Log what makes the data suspect: missing or repeated frames, a frame rate that wasn't the set one."""
        d = self.details
        if d["missing_rows"]:
            log.warning("%d of %d rows have no profile: frames the sensor didn't send (left empty)", d["missing_rows"], d["rows"])
        for key, what in (("repeated", "repeated frames"), ("out_of_order", "frames from before the first one")):
            if d[key]:
                log.warning("%d %s were ignored", d[key], what)
        if (measured := d.get("measured_frame_rate")) and abs(measured - self.frame_rate) > 0.01 * self.frame_rate:
            # Rows are frames, so the y spacing is only right at the configured rate.
            log.warning("profiles came at %.4g Hz, not the configured %g Hz: the y spacing assumes %g Hz",
                        measured, self.frame_rate, self.frame_rate)
        if cut := d.get("discarded_at_stop"):
            log.warning("the sensor discards frames it hasn't processed when it stops: the last ~%.3g s "
                        "(~%d frames, ~%.3g mm) of the scan are missing", cut["seconds"], cut["frames"], cut["mm"])
        log.debug("profiles per message: %s", d["batch_sizes"])

    def save(self, out_dir: Path | str = "scans", name: str | None = None, info: dict[str, Any] | None = None) -> Path:
        """Write the scan to a new folder out_dir/name (default name: scan_<timestamp>): the image
        (CEND format) or the point cloud (PLY), and settings/ with the record. `info` is added to
        the record (the CLI puts its command line there). Returns the folder."""
        folder = scan_folder(out_dir, name)
        name = folder.name
        data, details = self._build()[0], self.details
        if isinstance(data, PointCloud):
            log.info("received %d profiles: %d points over %d rows", details["received"], details["points"], details["rows"])
            if self.negate_y:
                log.info("layout Reverse: point cloud y negated, so 3D views show the scan as it is")
            paths = write_ply(data, folder, name, self.y_resolution, self.negate_y)
        else:
            length, width = data.heights.data.shape
            log.info("received %d profiles: %d x %d", details["received"], width, length)
            paths = write_cend(data, folder, name)
        for path in paths:
            log.info("wrote %s", path)
        if self.snapshot is not None:
            record = {**(info or {}), "profiles": details, "report": report_dict(self.report)}
            for path in write_record(folder / "settings", name, self.snapshot, record):
                log.info("wrote %s", path)
        return folder


class ProfileScan:
    """A profile scan that runs in the background until stop() (or until `distance` is covered).

    settings: applied for this scan only (restored when it stops). frame_rate: a number, "max",
    or "auto" (travel speed / x spacing: y spacing = x spacing); None keeps the job's (or the one
    in `settings`). distance: stop by itself after that many mm (distance / y spacing profiles).
    timeout: how long to wait without any profile before giving up. before_start: called right
    before the sensor starts, in the caller's thread (the CLI's --wait / --delay).

    Use it as a context manager (stops and restores on the way out, also on errors), or call
    start() and stop() yourself. While it runs, use only its own attributes, not the scanner:
    the background thread is talking to the sensor.
    """

    def __init__(
        self,
        scanner: Scanner,
        settings: Settings | None = None,
        *,
        frame_rate: float | str | None = None,
        distance: float | None = None,
        timeout: float = 120.0,
        before_start: Callable[[], None] | None = None,
    ):
        if distance is not None and distance <= 0:
            raise ScannerError("distance must be positive")
        self.scanner = scanner
        self.settings = settings or Settings()
        self.auto_frame_rate = frame_rate == "auto"
        if frame_rate == "max":
            self.settings = replace(self.settings, max_frame_rate=True, frame_rate=None)
        elif isinstance(frame_rate, int | float):
            self.settings = replace(self.settings, frame_rate=float(frame_rate), max_frame_rate=None)
        elif frame_rate not in (None, "auto"):
            raise ScannerError(f"frame_rate: expected a number, 'max' or 'auto', got {frame_rate!r}")
        self.distance = distance
        self.timeout = timeout
        self.before_start = before_start
        self.result: ScanResult | None = None
        self._stop = threading.Event()
        self._done = threading.Event()
        self._thread: threading.Thread | None = None
        self._frames: ProfileFrames | None = None
        self._restore = contextlib.ExitStack()
        self._error: BaseException | None = None
        self._report = ScanReport()
        # Known once started: what the scan runs with.
        self.frame_rate = 0.0  # Hz
        self.y_resolution = 0.0  # mm per row
        self.negate_y = False
        self.snapshot: Snapshot | None = None
        # How it ended, once it has: "stop" (stop() or the with block), "distance", "sensor stopped"
        # (by something else: the web UI, another client), or "error". None while running.
        self.ended: str | None = None

    # Progress, safe to read while the scan runs.

    @property
    def received(self) -> int:
        """Profiles received so far."""
        return self._frames.received if self._frames else 0

    @property
    def rows(self) -> int:
        """Rows (frames since the first profile) covered so far."""
        return self._frames.span if self._frames else 0

    @property
    def running(self) -> bool:
        return self._thread is not None and not self._done.is_set()

    def start(self) -> Self:
        """Apply the settings, then start the sensor and the background thread; returns at once."""
        if self._thread is not None:
            raise ScannerError("this scan was already started")
        scanner = self.scanner
        try:
            mark = self._restore.enter_context(temporary_settings(scanner))
            if self.settings != Settings():
                scanner.apply_settings(self.settings)
            if self.auto_frame_rate:
                apply_auto_frame_rate(scanner)
            s = scanner.get_settings()
            if s.scan_mode != "profile":
                raise ScannerError(f"a profile scan needs the scan mode profile (it is {s.scan_mode})")
            if s.trigger_source != "time":
                raise ScannerError(f"profile scans need time triggering (the trigger source is {s.trigger_source})")
            if not s.travel_speed:
                raise ScannerError("profile scans need the travel speed")
            if not s.frame_rate:
                raise ScannerError("cannot read the frame rate")
            self.frame_rate = s.frame_rate
            self.y_resolution = s.travel_speed / s.frame_rate
            rows = None if self.distance is None else max(1, round(self.distance / self.y_resolution))
            cloud = s.uniform_spacing is False  # the sensor's points, kept as a point cloud
            self.negate_y = cloud and s.orientation == "reverse"  # see ProfileCloud.cloud
            length = "until stopped" if rows is None else f"{self.distance:g} mm ({rows} profiles)"
            log.info("scanning %s at %g Hz (y spacing %.4g mm)%s", length, s.frame_rate, self.y_resolution,
                     "; point cloud" if cloud else "")
            # The scan's settings are in place: from here on, they are what it runs with.
            mark()
            scanner.enable_outputs()  # Start would do it; first, so the snapshot includes it
            self.snapshot = take_snapshot(scanner)
            self._frames = ProfileCloud(rows) if cloud else ProfileImage(rows)
            if self.before_start:
                self.before_start()
        except BaseException:
            self._restore.close()
            raise
        self._thread = threading.Thread(target=self._run, name="gocator-profile-scan", daemon=True)
        self._thread.start()
        return self

    def _run(self) -> None:
        assert self._frames is not None
        try:
            self.ended = scan_profiles(self.scanner, self._frames, self.timeout, stop=self._stop, report=self._report)
        except BaseException as e:  # noqa: BLE001  -- whatever ends the scan reaches the caller through stop()
            self._error = e
            self.ended = "error"
        finally:
            self._done.set()

    def wait(self, timeout: float | None = None) -> bool:
        """Wait until the scan ends by itself (distance covered, the sensor stopped elsewhere, or an
        error); True if it did. `ended` then says how."""
        if self._thread is None:
            raise ScannerError("the scan was not started")
        return self._done.wait(timeout)

    def stop(self) -> ScanResult:
        """Stop the scan (receiving the profiles still on their way), restore the settings and
        return the result. Raises what ended the scan early, if anything did; `result` then
        still has what arrived until then."""
        if self._thread is None:
            raise ScannerError("the scan was not started")
        if self.result is None:
            self._stop.set()
            self._thread.join()
            self._restore.close()
            assert self._frames is not None
            error = None if self._error is None else str(self._error) or type(self._error).__name__
            self.result = ScanResult(self._frames, self.y_resolution, self.frame_rate, self.negate_y, self._report,
                                     self.snapshot, error, self.ended)
            if self._frames.received:
                self.result.warn()
        if self._error is not None:
            raise self._error
        return self.result

    def __enter__(self) -> Self:
        return self.start()

    def __exit__(self, exc_type, exc, tb) -> None:
        if self._thread is None:
            return
        try:
            self.stop()
        except BaseException:
            if exc is None:  # don't hide the caller's own exception behind the scan's
                raise

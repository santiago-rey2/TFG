"""A fake classic Gocator speaking the Gocator Protocol on real TCP sockets.

It answers the control commands both backends use (GoSdk also needs a health channel and
a few commands while connecting) and, on Start (or on Software
Trigger with software_trigger=True), sends one Stamp + Uniform Surface + Surface
Intensity group on the data channel; with repeat=True it keeps sending them until Stop,
like fixed-length surfaces with a sequential start. In Profile mode it streams profiles
instead, `profile_batch` per message group, until Stop: uniform profiles, or point clouds
when uniform spacing is off (`drop_frames` are never sent), counting them in the scan count
health indicator. With replay=..., it sends those
raw bytes instead (e.g. a capture saved with `gocator scan --save-raw`). On the health channel
it sends the indicators in `indicators` every health_interval seconds; `per_surface` says
how much each grows per surface sent (drops_per_surface: processing drops).

Like a sensor, it computes the maximum frame rate when the configuration is written:
surface generation allows less for longer surfaces (see update_limits).

Run standalone with `gocator-mock`, then `gocator scan --host 127.0.0.1`.
"""

import argparse
import logging
import socket
import struct
import threading
import time
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

import numpy as np

from .backends.protocol import config
from .backends.protocol.client import (
    CMD_COPY_FILE,
    CMD_GET_LOADED_JOB,
    CMD_GET_STATES,
    CMD_GET_SYSTEM_INFO_2,
    CMD_LIST_FILES,
    CMD_READ_FILE,
    CMD_SET_DEFAULT_JOB,
    CMD_SOFTWARE_TRIGGER,
    CMD_START,
    CMD_STOP,
    CMD_WRITE_FILE,
    CONTROL_PORT,
    DATA_PORT,
    HEALTH_HEADER,
    INDICATOR,
    LAST_MESSAGE_FLAG,
    LIVE_CONFIG,
    LIVE_JOB,
    LIVE_TRANSFORM,
    MSG_HEALTH,
    MSG_PROFILE_INTENSITY,
    MSG_PROFILE_POINT_CLOUD,
    MSG_STAMP,
    MSG_SURFACE_INTENSITY,
    MSG_UNIFORM_PROFILE,
    MSG_UNIFORM_SURFACE,
    STAMP_HEADER,
    STATUS_OK,
    decode_name,
    file_name,
    recv_exactly,
)
from .scanner import (
    CHOICES,
    HEALTH_SCAN_COUNT,
    INVALID_RANGE,
    Grid,
    Scan,
    ScannerError,
    Settings,
    format_number,
)

log = logging.getLogger(__name__)

STATUS_INVALID_STATE = -1000
STATUS_ITEM_NOT_FOUND = -999
STATUS_INVALID_COMMAND = -998
STATUS_INVALID_PARAMETER = -997
STATUS_NOT_SUPPORTED = -996
STATE_COUNT = 17  # state variables in a 6.x Get States reply

# What GoSdk needs to connect (see its Internal/GoControl.c and GoSensor.c).
CMD_GET_PROTOCOL_VERSION = 0x4511
CMD_SET_DATETIME = 0x4610
CMD_READ_FILE_STREAMED = 0x4529  # GoSensor_DownloadFile
CONTINUE = 0x5000  # message type of the chunks after a streamed reply
PROTOCOL_VERSION = (101, 23)  # GoSdk 6.5's; it accepts any 101.x
FIRMWARE_VERSION = (6, 5, 0, 0)
SERIAL_NUMBER = 12345
HEALTH_PORT = 3194

SUBSAMPLING_DEFAULTS = {"x": 1, "z": 2}  # the mock's default subsampling divisors
# x spacing (mm) of the spacing type presets: max-res, balanced, max-speed.
SPACING_PRESETS = {0: 0.0125, 1: 0.025, 2: 0.05}
# Frame rate cap the mock computes. Surface generation: inversely proportional to the
# surface length, matching CEND's job (426.088 Hz for 700 mm); the camera: a fixed rate.
SURFACE_RATE_LENGTH = 426.088 * 700  # Hz * mm
CAMERA_MAX_RATE = 5000.0  # Hz


def merge_values(current: ET.Element, written: ET.Element) -> None:
    """Take the setting values (element text) from a written config, like a sensor does:
    constraint attributes (min, max, options) are kept, as the sensor computes them (GoSdk
    writes values only), and elements this firmware doesn't know are ignored."""
    seen: Counter[str] = Counter()
    for child in written:
        index = seen[child.tag]
        seen[child.tag] += 1
        matches = current.findall(child.tag)
        if index >= len(matches):
            continue
        if len(child):
            merge_values(matches[index], child)
        else:
            matches[index].text = child.text


def update_limits(cfg: ET.Element) -> None:
    """Recompute what the sensor derives from the written settings: the frame rate cap
    (FrameRate max, maxSource) and the x spacing in use (SpacingInterval value)."""
    # Subsampling in use: the sensor's default (1/2 for z, like a 2640's) while that is on.
    for axis, (path, default_path) in config.SUBSAMPLING.items():
        el, default = cfg.find(path), cfg.find(default_path)
        if el is not None:
            on = default is not None and (default.text or "").strip() == "1"
            el.set("value", str(SUBSAMPLING_DEFAULTS[axis] if on else int(el.text or 1)))
    spacing = cfg.find(config.SPACING)
    spacing_type = cfg.find(config.ENUMS["x_spacing_type"])
    if spacing is not None and spacing_type is not None:
        used = SPACING_PRESETS.get(int(spacing_type.text or 3), float(spacing.text or 0))
        spacing.set("value", format_number(used))
    # Like a sensor, it offers the Ethernet outputs of the current scan mode only.
    profile = (cfg.findtext("Setup/ScanMode") or "").strip() == str(CHOICES["scan_mode"].index("profile"))
    for tags, offered in ((("Surfaces", "SurfaceIntensities"), not profile), (("Profiles", "ProfileIntensities"), profile)):
        for tag in tags:
            if (el := cfg.find(f"Output/Ethernet/{tag}")) is not None:
                el.set("options", "0" if offered else "")
    rate = cfg.find("Setup/Trigger/FrameRate")
    length = cfg.find("Setup/SurfaceGeneration/FixedLength/Length")
    enabled = cfg.find("Setup/Trigger/MaxFrameRateEnabled")
    if rate is None or length is None:
        return
    cap, source = SURFACE_RATE_LENGTH / float(length.text or 1), 1
    if profile or cap > CAMERA_MAX_RATE:  # no surface generation in Profile mode
        cap, source = CAMERA_MAX_RATE, 0
    cap = round(cap, 3)
    rate.set("max", format_number(cap))
    rate.set("maxSource", str(source))
    if (enabled is not None and (enabled.text or "").strip() == "1") or float(rate.text or 0) > cap:
        rate.text = format_number(cap)


def message(msg_type: int, body: bytes, last: bool = False) -> bytes:
    control = msg_type | (LAST_MESSAGE_FLAG if last else 0)
    return struct.pack("<IH", 6 + len(body), control) + body


def stamp_body(frame_index: int, timestamp: int) -> bytes:
    # frameIndex, timestamp, encoder, encoderAtZ, status, serialNumber, reserved x3 (u32, u64), ptpTimestamp
    stamp = struct.pack("<QQqqQIIQQ", frame_index, timestamp, 0, 0, 0, 12345, 0, 0, 0)
    return STAMP_HEADER.pack(1, len(stamp), 0, 0) + stamp


def _nm(mm: float) -> int:
    return round(mm * 1e6)


def _um(mm: float) -> int:
    return round(mm * 1e3)


def surface_body(grid: Grid) -> bytes:
    length, width = grid.data.shape
    attrs = struct.pack(
        "<5I3iBII3x",  # 44 bytes: protocol version 1 attributes
        length, width,
        _nm(grid.x_resolution), _nm(grid.y_resolution), _nm(grid.z_resolution or 0),
        _um(grid.x_offset), _um(grid.y_offset), _um(grid.z_offset or 0),
        0, 100 * 1024, 0,  # source, exposure, reserved
    ) + struct.pack("<4i", 3, 0, 0, 0)  # streamStep (surface), streamStepId, arrayed count/index
    return struct.pack("<H", len(attrs)) + attrs + grid.data.astype("<i2").tobytes()


def intensity_body(grid: Grid) -> bytes:
    length, width = grid.data.shape
    attrs = struct.pack(
        "<4I2iBI3x",  # 32 bytes: protocol version 1 attributes
        length, width,
        _nm(grid.x_resolution), _nm(grid.y_resolution),
        _um(grid.x_offset), _um(grid.y_offset),
        0, 100 * 1024,
    ) + struct.pack("<4i", 3, 0, 0, 0)
    return struct.pack("<H", len(attrs)) + attrs + grid.data.astype("u1").tobytes()


def stamps_body(frames, timestamps_us) -> bytes:
    stamps = b"".join(
        struct.pack("<QQqqQIIQQ", f, round(t * 1.024), 0, 0, 0, 12345, 0, 0, 0) for f, t in zip(frames, timestamps_us)
    )
    return STAMP_HEADER.pack(len(frames), 64, 0, 0) + stamps


def profile_body(ranges: np.ndarray, x_resolution: float, z_resolution: float, x_offset: float, z_offset: float) -> bytes:
    """A Uniform Profile ((count, width) ranges) or Profile Point Cloud ((count, width, 2)) body."""
    count, width = ranges.shape[:2]
    attrs = struct.pack(
        "<4I2iBI3B", count, width, _nm(x_resolution), _nm(z_resolution), _um(x_offset), _um(z_offset),
        0, 100 * 1024, 0, 0, 0,  # source, exposure, camera index / reserved
    ) + struct.pack("<4i", 2, 0, 0, 0)  # streamStep (profile), streamStepId, arrayed count/index
    return struct.pack("<H", len(attrs)) + attrs + ranges.astype("<i2").tobytes()


def profile_intensity_body(values: np.ndarray, x_resolution: float, x_offset: float) -> bytes:
    count, width = values.shape
    attrs = struct.pack("<3IiBI3B", count, width, _nm(x_resolution), _um(x_offset), 0, 100 * 1024, 0, 0, 0)
    attrs += struct.pack("<4i", 2, 0, 0, 0)
    return struct.pack("<H", len(attrs)) + attrs + values.astype("u1").tobytes()


POINT_CLOUD_X_RESOLUTION = 0.002  # mm per x count in the mock's point clouds


def profile_group(scan: Scan, frames: list[int], timestamps_us: list[float], uniform: bool) -> bytes:
    """Encode frames of a scan (row = frame - 1, wrapping) as the group a sensor sends in Profile mode."""
    heights, intensity = scan.heights, scan.intensity
    rows = np.array([(f - 1) % len(heights.data) for f in frames])
    ranges = heights.data[rows]
    if uniform:
        body = profile_body(ranges, heights.x_resolution, heights.z_resolution or 0, heights.x_offset, heights.z_offset or 0)
        msg_type = MSG_UNIFORM_PROFILE
    else:
        # The same points with explicit x: one per column, encoded relative to x = 0.
        x = heights.x_offset + heights.x_resolution * np.arange(ranges.shape[1])
        xr = np.broadcast_to(np.rint(x / POINT_CLOUD_X_RESOLUTION).astype(np.int16), ranges.shape)
        points = np.stack([np.where(ranges == INVALID_RANGE, INVALID_RANGE, xr), ranges], axis=-1)
        body = profile_body(points, POINT_CLOUD_X_RESOLUTION, heights.z_resolution or 0, 0.0, heights.z_offset or 0)
        msg_type = MSG_PROFILE_POINT_CLOUD
    parts = [message(MSG_STAMP, stamps_body(frames, timestamps_us)), message(msg_type, body, last=intensity is None)]
    if intensity is not None:
        values = profile_intensity_body(intensity.data[rows], intensity.x_resolution, intensity.x_offset)
        parts.append(message(MSG_PROFILE_INTENSITY, values, last=True))
    return b"".join(parts)


def scan_group(scan: Scan, frame_index: int = 0, timestamp_us: float | None = None) -> bytes:
    """Encode a scan as the message group a sensor sends for one surface."""
    ticks = 1024 * frame_index if timestamp_us is None else round(timestamp_us * 1.024)
    parts = [message(MSG_STAMP, stamp_body(frame_index, ticks))]
    parts.append(message(MSG_UNIFORM_SURFACE, surface_body(scan.heights), last=scan.intensity is None))
    if scan.intensity is not None:
        parts.append(message(MSG_SURFACE_INTENSITY, intensity_body(scan.intensity), last=True))
    return b"".join(parts)


def synthetic_scan(length: int = 400, width: int = 640) -> Scan:
    """A tilted plane with a dome in the middle and a strip of missing data on the left."""
    y, x = np.mgrid[0:length, 0:width]
    r = min(length, width) / 4
    dist = np.hypot(x - width / 2, y - length / 2)
    z = 2000 + 3 * x + 50 * np.sqrt(np.clip(r**2 - dist**2, 0, None))
    ranges = z.astype(np.int16)
    ranges[:, :20] = INVALID_RANGE
    geometry = dict(x_resolution=0.1, y_resolution=0.2, x_offset=-32.0, y_offset=0.0)
    return Scan(
        heights=Grid(ranges, z_resolution=0.002, z_offset=-10.0, **geometry),
        intensity=Grid(((x + y) % 256).astype(np.uint8), **geometry),
    )


# A real config.xml: complete enough for GoSdk, which parses all of it. Its ranges differ from a 2640's.
REAL_CONFIG = (Path(__file__).parent / "data" / "cend_config.xml").read_bytes()


def _mock_config() -> bytes:
    """The real config with a sequential start and the Ethernet outputs cleared (so that
    enabling them is exercised). Like a 2640's, it has default Z subsampling, switched on."""
    cfg = config.parse(REAL_CONFIG)
    config.apply_settings(cfg, None, Settings(surface_start="sequential"))
    z = cfg.find(config.SUBSAMPLING["z"][0])
    assert z is not None
    device = cfg.find(config.DEVICE)
    assert device is not None
    default = ET.Element("ZSubsamplingDefaultEnabled", used="1")
    default.text = "1"
    device.insert(list(device).index(z) + 1, default)
    update_limits(cfg)
    for tag in ("Surfaces", "SurfaceIntensities"):
        el = cfg.find(f"Output/Ethernet/{tag}")
        assert el is not None
        el.text = ""
    return config.serialize(cfg)


MOCK_CONFIG = _mock_config()
MOCK_TRANSFORM = b"""<?xml version="1.0" encoding="UTF-8"?>
<Transform version="100">
  <EncoderResolution>1</EncoderResolution>
  <Speed>50</Speed>
  <Devices>
    <Device role="0">
      <X>0</X>
      <Y>0</Y>
      <Z>0</Z>
      <XAngle>0</XAngle>
      <YAngle>0</YAngle>
      <ZAngle>0</ZAngle>
    </Device>
  </Devices>
</Transform>
"""


class MockSensor:
    def __init__(
        self,
        scan: Scan | None = None,
        host: str = "127.0.0.1",
        control_port: int = 0,
        data_port: int = 0,
        health_port: int = 0,
        software_trigger: bool = False,
        scan_delay: float = 0.0,
        replay: bytes | None = None,
        repeat: bool = False,
        drop: tuple[int, ...] = (),
        drops_per_surface: int = 0,
        health_interval: float = 0.05,
        profile_batch: int = 4,
        drop_frames: tuple[int, ...] = (),
        profile_interval: float = 0.002,
        lose_frames: tuple[int, ...] = (),
        late_after_stop: float = 0.0,
    ):
        self.scan = scan or synthetic_scan()
        self.replay = replay
        self.repeat = repeat  # keep sending surfaces until Stop
        self.drop = set(drop)  # surfaces (0 = first after Start) not sent, to fake lost data
        self._sent = 0  # surfaces since Start, including dropped ones
        # Health indicators: CPU usage, speed, processing/trigger/Ethernet/output drops.
        self.indicators = {2007: 20, 2034: 0x8020, 20001: 0, 21000: 0, 21010: 0, 21005: 0, 21011: 0}
        # The sensor log (_live.log): (level, text with %s, args); log_on_start is added on Start.
        self.log: list[tuple[str, str, list[str]]] = []
        self.log_on_start: list[tuple[str, str, list[str]]] = []
        self.per_surface = {21000: drops_per_surface}  # per surface, or per profile group in Profile mode
        self.profile_batch = profile_batch  # profiles per message group in Profile mode
        self.drop_frames = set(drop_frames)  # frame indexes never sent, to fake lost profiles
        self.profile_interval = profile_interval  # s between profile groups
        # Frame indexes the scan count (indicator 20005) includes that never arrive, as if lost
        # on the network; and how long after Stop one more batch comes (counted at Stop).
        self.lose_frames = set(lose_frames)
        self.late_after_stop = late_after_stop
        self.health_interval = health_interval
        self._closed = threading.Event()
        self.scan_delay = scan_delay  # seconds between Start/trigger and the surface
        self.running = False
        self.commands: list[int] = []  # received command ids, for tests
        # Sensor storage: the live job (config + transform) and saved jobs, by name.
        self.live = {LIVE_CONFIG: MOCK_CONFIG, LIVE_TRANSFORM: MOCK_TRANSFORM}
        if software_trigger:
            self.set_live_settings(Settings(surface_generation="fixed", surface_start="software"))
        self.jobs = {"default": dict(self.live)}
        self.loaded_job, self.job_changed, self.default_job = "default", False, "default"
        self._lock = threading.Lock()
        self._data_conns: list[socket.socket] = []
        self._health_conns: list[socket.socket] = []  # GoSdk connects; the mock sends nothing on it
        self._data_connected = threading.Event()
        self._listeners = [socket.create_server((host, port)) for port in (control_port, data_port, health_port)]
        self.control_port, self.data_port, self.health_port = (s.getsockname()[1] for s in self._listeners)
        handlers = (self._handle_control, self._add_data_conn, self._health_conns.append)
        for listener, handler in zip(self._listeners, handlers):
            threading.Thread(target=self._serve, args=(listener, handler), daemon=True).start()
        threading.Thread(target=self._send_health, daemon=True).start()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def close(self) -> None:
        self._closed.set()
        for listener in self._listeners:
            listener.close()
        with self._lock:
            for conn in self._data_conns + self._health_conns:
                conn.close()

    def live_settings(self) -> Settings:
        cfg = config.parse(self.live[LIVE_CONFIG])
        return config.read_settings(cfg, config.parse(self.live[LIVE_TRANSFORM]))

    def set_live_settings(self, settings: Settings) -> None:
        cfg = config.parse(self.live[LIVE_CONFIG])
        tfm = config.parse(self.live[LIVE_TRANSFORM])
        config.apply_settings(cfg, tfm, settings)
        update_limits(cfg)
        self.live = {LIVE_CONFIG: config.serialize(cfg), LIVE_TRANSFORM: config.serialize(tfm)}

    def _serve(self, listener: socket.socket, handler) -> None:
        while True:
            try:
                conn, _ = listener.accept()
            except OSError:
                return  # listener closed
            threading.Thread(target=handler, args=(conn,), daemon=True).start()

    def _add_data_conn(self, conn: socket.socket) -> None:
        conn.settimeout(5)  # a client that stopped reading must not block the mock forever
        with self._lock:
            self._data_conns.append(conn)
        self._data_connected.set()

    def _handle_control(self, conn: socket.socket) -> None:
        with conn:
            while True:
                try:
                    size, command_id = struct.unpack("<IH", recv_exactly(conn, 6))
                    payload = recv_exactly(conn, size - 6)
                except (ScannerError, OSError):
                    return
                status, reply, *after = self._execute(command_id, payload)
                conn.sendall(struct.pack("<IHi", 10 + len(reply), command_id, status) + reply + b"".join(after))

    def _execute(self, command_id: int, payload: bytes) -> tuple[int, bytes] | tuple[int, bytes, bytes]:
        """Returns the reply status and payload, and for streamed replies the messages after it."""
        self.commands.append(command_id)
        if command_id == CMD_GET_STATES:
            states = [0] * STATE_COUNT
            states[0] = int(self.running)
            return STATUS_OK, struct.pack(f"<I{STATE_COUNT}i", STATE_COUNT, *states)
        if command_id == CMD_START:
            if self.running:
                return STATUS_INVALID_STATE, b""
            self.running = True
            self._sent = 0
            self.indicators[HEALTH_SCAN_COUNT] = 0  # profiles sent since Start
            self.log += self.log_on_start
            settings = self.live_settings()
            if settings.scan_mode == "profile":
                threading.Thread(target=self._stream_profiles, args=(settings,), daemon=True).start()
            elif not settings.needs_software_trigger():
                self._emit_later()
            return STATUS_OK, b""
        if command_id == CMD_STOP:
            self.running = False
            return STATUS_OK, b""
        if command_id == CMD_SOFTWARE_TRIGGER:
            if not self.running:
                return STATUS_INVALID_STATE, b""
            if self.live_settings().needs_software_trigger():
                self._emit_later()
            return STATUS_OK, b""
        if command_id == CMD_READ_FILE:
            return self._read_file(decode_name(payload[:64]))
        if command_id == CMD_WRITE_FILE:
            (length,) = struct.unpack_from("<I", payload, 64)
            return self._write_file(decode_name(payload[:64]), payload[68 : 68 + length])
        if command_id == CMD_COPY_FILE:
            return self._copy_file(decode_name(payload[:64]), decode_name(payload[64:128]))
        if command_id == CMD_LIST_FILES:
            extension = decode_name(payload[:64])
            names = [f"{job}.job" for job in self.jobs if extension in ("", "job")]
            return STATUS_OK, struct.pack("<I", len(names)) + b"".join(file_name(n) for n in names)
        if command_id == CMD_GET_LOADED_JOB:
            return STATUS_OK, file_name(f"{self.loaded_job}.job") + bytes([self.job_changed])
        if command_id == CMD_SET_DEFAULT_JOB:
            job = decode_name(payload[:64]).removesuffix(".job")
            if job not in self.jobs:
                return STATUS_ITEM_NOT_FOUND, b""
            self.default_job = job
            return STATUS_OK, b""
        # Commands only GoSdk sends (while connecting).
        if command_id == CMD_GET_PROTOCOL_VERSION:
            return STATUS_OK, bytes(PROTOCOL_VERSION)
        if command_id == CMD_GET_SYSTEM_INFO_2:
            # id, IP, part number[32], firmware version, state, role (0 = main); then no remote sensors, no buddies
            info = struct.pack("<I4s32s4Bii", SERIAL_NUMBER, bytes([127, 0, 0, 1]), b"2640", *FIRMWARE_VERSION, int(self.running), 0)
            return STATUS_OK, struct.pack("<H", len(info)) + info + struct.pack("<IHIH", 0, 0, 0, 0)
        if command_id == CMD_READ_FILE_STREAMED:
            status, reply = self._read_file(decode_name(payload[:64]))
            if status != STATUS_OK:
                return status, b""
            data = reply[4:]
            # Reply: progress total, progress; then data chunks, the last one empty.
            chunks = b"".join(
                struct.pack("<IHiIII", 22 + len(chunk), CONTINUE, STATUS_OK, 100, 100, len(chunk)) + chunk
                for chunk in (data, b"")
            )
            return STATUS_OK, struct.pack("<II", 100, 0), chunks
        if command_id == CMD_SET_DATETIME:
            return STATUS_OK, b""
        log.debug("mock: unknown command 0x%04x", command_id)
        return STATUS_INVALID_COMMAND, b""

    def _read_file(self, name: str) -> tuple[int, bytes]:
        job, _, part = name.partition(".job/")
        if name == "_live.log":
            data = self._log_xml()
        elif name in self.live:
            data = self.live[name]
        elif part == "config.xml" and job in self.jobs:
            data = self.jobs[job][LIVE_CONFIG]
        else:
            return STATUS_ITEM_NOT_FOUND, b""
        return STATUS_OK, struct.pack("<I", len(data)) + data

    def _log_xml(self) -> bytes:
        root = ET.Element("Log", idStart="1", idEnd=str(len(self.log)))
        for i, (level, text, args) in enumerate(self.log, start=1):
            entry = ET.SubElement(root, level, time="0", source="0", id=str(i), value=text)
            for arg in args:
                ET.SubElement(entry, "Arg", value=arg)
        return config.serialize(root)

    def _write_file(self, name: str, data: bytes) -> tuple[int, bytes]:
        if name not in self.live:
            return STATUS_NOT_SUPPORTED, b""  # the mock only stores the live config files
        if self.running:
            return STATUS_INVALID_STATE, b""
        try:
            current, written = config.parse(self.live[name]), config.parse(data)
        except ScannerError:
            return STATUS_INVALID_PARAMETER, b""  # invalid XML
        merge_values(current, written)
        if name == LIVE_CONFIG:
            update_limits(current)
        self.live[name] = config.serialize(current)
        self.job_changed = True
        return STATUS_OK, b""

    def _copy_file(self, source: str, destination: str) -> tuple[int, bytes]:
        if destination == LIVE_JOB:  # load a job
            job = source.removesuffix(".job")
            if job not in self.jobs:
                return STATUS_ITEM_NOT_FOUND, b""
            if self.running:
                return STATUS_INVALID_STATE, b""
            self.live = dict(self.jobs[job])
            self.loaded_job, self.job_changed = job, False
        elif source == LIVE_JOB:  # save the live job
            job = destination.removesuffix(".job")
            self.jobs[job] = dict(self.live)
            self.loaded_job, self.job_changed = job, False
        else:
            return STATUS_NOT_SUPPORTED, b""
        return STATUS_OK, b""

    def _emit_later(self) -> None:
        threading.Timer(self.scan_delay, self._emit).start()

    def _emit(self) -> None:
        if not self._data_connected.wait(2):
            log.warning("no data client connected; surface dropped")
        while True:
            number, self._sent = self._sent, self._sent + 1
            for indicator, step in self.per_surface.items():
                self.indicators[indicator] = self.indicators.get(indicator, 0) + step
            if number not in self.drop:
                # Like a sensor: surfaces are numbered from 1 after Start, and one frame per
                # row means each one is rows / frame rate later than the one before.
                rate = self.live_settings().frame_rate or 1
                timestamp = number * len(self.scan.heights.data) / rate * 1e6
                payload = self.replay if self.replay is not None else scan_group(self.scan, number + 1, timestamp)
                self._send(payload)
            if not self.repeat:
                return
            time.sleep(max(self.scan_delay, 0.01))
            if not self.running:
                return

    def _stream_profiles(self, settings: Settings) -> None:
        if not self._data_connected.wait(2):
            log.warning("no data client connected; profiles dropped")
        rate = settings.frame_rate or 1
        frame = 1
        while self.running:
            frames = [f for f in range(frame, frame + self.profile_batch) if f not in self.drop_frames]
            frame += self.profile_batch
            for indicator, step in self.per_surface.items():
                self.indicators[indicator] = self.indicators.get(indicator, 0) + step
            self.indicators[HEALTH_SCAN_COUNT] += len(frames)  # lost ones too: sent, never received
            frames = [f for f in frames if f not in self.lose_frames]
            if frames:
                times = [(f - 1) / rate * 1e6 for f in frames]
                self._send(profile_group(self.scan, frames, times, settings.uniform_spacing is not False))
            time.sleep(self.profile_interval)
        if self.late_after_stop:  # one more batch, taken before Stop but sent long after it
            frames = list(range(frame, frame + self.profile_batch))
            self.indicators[HEALTH_SCAN_COUNT] += len(frames)
            time.sleep(self.late_after_stop)
            times = [(f - 1) / rate * 1e6 for f in frames]
            self._send(profile_group(self.scan, frames, times, settings.uniform_spacing is not False))

    def _send_health(self) -> None:
        while not self._closed.wait(self.health_interval):
            values = dict(self.indicators)
            body = HEALTH_HEADER.pack(len(values), 0) + b"".join(INDICATOR.pack(i, 0, v) for i, v in values.items())
            payload = message(MSG_HEALTH, body, last=True)
            with self._lock:
                for conn in list(self._health_conns):
                    try:
                        conn.sendall(payload)
                    except OSError:
                        self._health_conns.remove(conn)

    def _send(self, payload: bytes) -> None:
        with self._lock:
            for conn in list(self._data_conns):
                try:
                    conn.sendall(payload)
                except OSError:
                    self._data_conns.remove(conn)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a fake classic Gocator sensor.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--control-port", type=int, default=CONTROL_PORT)
    parser.add_argument("--data-port", type=int, default=DATA_PORT)
    parser.add_argument("--health-port", type=int, default=HEALTH_PORT)
    parser.add_argument("--software-trigger", action="store_true", help="send the surface on Software Trigger instead of on Start")
    parser.add_argument("--scan-delay", type=float, default=1.0, help="seconds the fake scan takes")
    parser.add_argument("--repeat", action="store_true", help="keep sending surfaces until Stop (fixed length, sequential start)")
    parser.add_argument("--drops-per-surface", type=int, default=0, help="processing drops reported on the health channel per surface")
    parser.add_argument("--replay", type=Path, help="raw capture (from gocator scan --save-raw) to send instead of the synthetic scan")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    replay = args.replay.read_bytes() if args.replay else None
    with MockSensor(
        host=args.host,
        control_port=args.control_port,
        data_port=args.data_port,
        health_port=args.health_port,
        software_trigger=args.software_trigger,
        scan_delay=args.scan_delay,
        replay=replay,
        repeat=args.repeat,
        drops_per_surface=args.drops_per_surface,
        health_interval=1.0,
    ) as sensor:
        log.info(
            "mock sensor on %s (control %d, data %d, health %d); Ctrl+C to quit",
            args.host, sensor.control_port, sensor.data_port, sensor.health_port,
        )
        try:
            threading.Event().wait()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
